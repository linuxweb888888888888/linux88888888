const express = require('express');
const mongoose = require('mongoose');
const ccxt = require('ccxt');

// ==================== CONFIGURATION ====================
const MONGO_URI = process.env.MONGO_URI || "mongodb+srv://web88888888888888_db_user:ZETrZHXzaxoekjkm@clusterweb8888.l0rv6hv.mongodb.net/botdb?appName=Clusterweb8888";
const PORT = 3000;

// === COIN PAIR & SCRAPER SETTINGS ===
// Note: Changed FEED_SYMBOL to Swap format to match the Scraper's HTX options
const FEED_SYMBOL = 'PEPE/USDT:USDT';    // <--- The pair to fetch LIVE PRICES via WebSockets
const HITBTC_SYMBOL = 'PEPE/USDT:USDT';  // <--- The pair to execute ORDERS on HitBTC Futures
const SAVE_INTERVAL_MS = 2000;           // <--- How often to save DB & tick bot logic

// ==================== PRICE FEED SETUP (HTX WEBSOCKETS) ====================
// Upgraded from ccxt.htx to ccxt.pro.htx for live WebSocket scraping
const priceFeed = new ccxt.pro.htx({ 
    options: { 
        defaultType: 'swap', 
        defaultSubType: 'linear' 
    } 
});

// ==================== HITBTC FUTURES API SETUP (ORDERS ONLY) ====================
const hitbtc = new ccxt.hitbtc({
    apiKey: 'YOUR_HITBTC_API_KEY',     // <--- ENTER YOUR API KEY
    secret: 'YOUR_HITBTC_API_SECRET',  // <--- ENTER YOUR API SECRET
    enableRateLimit: true,
    options: {
        defaultType: 'swap'            // <--- FORCES FUTURES/SWAP MARKET
    }
});
let isFirstTrade = true;               // Tracks if we need to open 1x or reverse (2x)

// ==================== MONGODB SCHEMA ====================
const ChartDataModel = mongoose.model('ChartData_V2', new mongoose.Schema({
    htxMid: Number, 
    timestamp: { type: Date, default: Date.now, expires: 86400 } // Auto-deletes data older than 24 hours
}));

const app = express();
app.use(express.json());

// CLI Colors
const colors = {
    green: "\x1b[32m", red: "\x1b[31m", gray: "\x1b[90m",
    reset: "\x1b[0m", cyan: "\x1b[36m", yellow: "\x1b[33m", magenta: "\x1b[35m"
};

// ==================== BOT STATE & SETTINGS ====================
let config = {
    contracts: 1000,
    leverage: 50,
    fastPeriod: 2,
    slowPeriod: 3, 
    window1: 55,
    window2: 55,
    window3: 55,
    chartTicks: 350 
};

let stats = {
    fastEMA: 0,
    slowEMA: 0,
    currentTrend: null, 
    trendEntryPrice: 0,
    totalClosedROI: 0,
    totalRealizedPNL: 0, 
    lastPrice: 0
};

// Memory arrays
let priceMemory = []; 
let fullChartHistory = []; 
let signalMemory = []; 
const MAX_PRICE_MEMORY = 2000; 
let isLiveStream = false;

let clients = [];

// ==================== LIVE RECALCULATION ENGINE ====================
function replayMemoryWithNewSettings() {
    const memoryCopy = [...priceMemory]; 
    
    // 1. Remember the trend BEFORE settings were changed
    const oldTrendBeforeSettingsChange = stats.currentTrend;
    
    // 2. Temporarily PAUSE live execution so it doesn't spam orders during historical replay
    const wasLive = isLiveStream;
    isLiveStream = false;
    
    // Wipe State completely clean
    stats.fastEMA = 0;
    stats.slowEMA = 0;
    stats.currentTrend = null;
    stats.trendEntryPrice = 0;
    stats.totalClosedROI = 0; 
    stats.totalRealizedPNL = 0;
    
    signalMemory = [];
    priceMemory = [];
    fullChartHistory = [];

    // Replay prices back into the logic instantly
    memoryCopy.forEach(pt => {
        thinkAndTrade(pt.price, pt.time);
    });
    
    // 3. RESTORE live execution status
    isLiveStream = wasLive;
    
    // 4. FIRE LIVE ORDER if the new settings caused the trend to flip!
    if (isLiveStream && stats.currentTrend !== null && stats.currentTrend !== oldTrendBeforeSettingsChange) {
        console.log(`\n${colors.cyan}[SYSTEM] UI Settings caused trend shift from ${oldTrendBeforeSettingsChange || 'NONE'} to ${stats.currentTrend}. Firing live order!${colors.reset}`);
        executeHitbtcReversal(stats.currentTrend);
    }
}

// ==================== HITBTC EXECUTION LOGIC ====================
async function executeHitbtcReversal(newTrend) {
    try {
        console.log(`\n${colors.yellow}===========================================`);
        console.log(`[HitBTC Futures] Initiating Position for Trend: ${newTrend}...`);
        
        const side = newTrend === 'BULLISH' ? 'buy' : 'sell';
        
        // If it's the first trade, just open 1x quantity.
        // If reversing an existing position, double the quantity to close the old and open the new.
        const orderQty = isFirstTrade ? config.contracts : (config.contracts * 2); 
        
        // Place market order on HitBTC Swap
        const order = await hitbtc.createMarketOrder(HITBTC_SYMBOL, side, orderQty);
        
        console.log(`[HitBTC Futures] SUCCESS: ${side.toUpperCase()} Order Filled! Qty: ${orderQty}`);
        console.log(`===========================================${colors.reset}\n`);
        
        isFirstTrade = false; // Subsequent trades will now be reversing (2x)
    } catch (err) {
        console.error(`\n${colors.red}[HitBTC API Error] Order failed: ${err.message}${colors.reset}\n`);
    }
}

// ==================== SMART EMA TREND LOGIC ====================
function thinkAndTrade(price, timestamp) {
    priceMemory.push({ price: price, time: timestamp });
    if (priceMemory.length > MAX_PRICE_MEMORY) {
        priceMemory.shift(); 
    }

    let fastK = 2 / (config.fastPeriod + 1);
    let slowK = 2 / (config.slowPeriod + 1);

    if (stats.fastEMA === 0 && stats.slowEMA === 0) {
        stats.fastEMA = price;
        stats.slowEMA = price;
    } else {
        stats.fastEMA = (price - stats.fastEMA) * fastK + stats.fastEMA;
        stats.slowEMA = (price - stats.slowEMA) * slowK + stats.slowEMA;
    }

    let rawSignal = signalMemory.length > 0 ? signalMemory[signalMemory.length - 1] : null;

    if (stats.fastEMA > stats.slowEMA) {
        rawSignal = "BULLISH";
    } else if (stats.fastEMA < stats.slowEMA) {
        rawSignal = "BEARISH";
    }

    let maxSignalWindow = Math.max(config.window1, config.window2, config.window3);

    if (rawSignal) {
        signalMemory.push(rawSignal);
        if (signalMemory.length > maxSignalWindow) {
            signalMemory.shift();
        }
    }

    let logData = {
        time: timestamp,
        price: price,
        trend: stats.currentTrend,
        fastEMA: stats.fastEMA,
        slowEMA: stats.slowEMA,
        roi: 0,
        unrealizedPNL: 0,
        confirmMsg: ""
    };

    if (signalMemory.length === maxSignalWindow) {
        let recentW1 = signalMemory.slice(-config.window1);
        let bullW1 = recentW1.filter(s => s === "BULLISH").length;
        let bearW1 = recentW1.filter(s => s === "BEARISH").length;

        let recentW2 = signalMemory.slice(-config.window2);
        let bullW2 = recentW2.filter(s => s === "BULLISH").length;
        let bearW2 = recentW2.filter(s => s === "BEARISH").length;

        let recentW3 = signalMemory.slice(-config.window3);
        let bullW3 = recentW3.filter(s => s === "BULLISH").length;
        let bearW3 = recentW3.filter(s => s === "BEARISH").length;

        let decidedTrend = stats.currentTrend;

        if (bullW1 > bearW1 && bullW2 > bearW2 && bullW3 > bearW3) {
            decidedTrend = "BULLISH";
        } else if (bearW1 > bullW1 && bearW2 > bullW2 && bearW3 > bullW3) {
            decidedTrend = "BEARISH";
        }

        // Close position & Realize PNL
        if (decidedTrend !== stats.currentTrend) {
            if (stats.currentTrend !== null) {
                let grossPnlPercent = stats.currentTrend === "BULLISH" 
                    ? ((price - stats.trendEntryPrice) / stats.trendEntryPrice) * 100
                    : ((stats.trendEntryPrice - price) / stats.trendEntryPrice) * 100;
                
                let absolutePNL = stats.currentTrend === "BULLISH"
                    ? (price - stats.trendEntryPrice) * config.contracts
                    : (stats.trendEntryPrice - price) * config.contracts;

                stats.totalClosedROI += (grossPnlPercent * config.leverage);
                stats.totalRealizedPNL += absolutePNL;
            }
            
            // ONLY execute real trades if live streaming (ignores historical DB backfill on startup)
            if (isLiveStream) {
                executeHitbtcReversal(decidedTrend);
            }

            stats.currentTrend = decidedTrend;
            stats.trendEntryPrice = price;
        }

        // Track Active Unrealized PNL
        if (stats.currentTrend !== null && stats.trendEntryPrice > 0) {
            let pnlPercent = stats.currentTrend === "BULLISH" 
                ? ((price - stats.trendEntryPrice) / stats.trendEntryPrice) * 100
                : ((stats.trendEntryPrice - price) / stats.trendEntryPrice) * 100;
                
            let absolutePNL = stats.currentTrend === "BULLISH"
                ? (price - stats.trendEntryPrice) * config.contracts
                : (stats.trendEntryPrice - price) * config.contracts;

            logData.roi = pnlPercent * config.leverage;
            logData.unrealizedPNL = absolutePNL;
        }

        if (stats.currentTrend === "BEARISH" && (bullW1 > 0 || bullW2 > 0 || bullW3 > 0)) {
            logData.confirmMsg = `[Confirming BEARISH: ${bullW1}/${config.window1} & ${bullW2}/${config.window2} & ${bullW3}/${config.window3}]`;
        } else if (stats.currentTrend === "BULLISH" && (bearW1 > 0 || bearW2 > 0 || bearW3 > 0)) {
            logData.confirmMsg = `[Confirming BULLISH: ${bearW1}/${config.window1} & ${bearW2}/${config.window2} & ${bearW3}/${config.window3}]`;
        }
    }

    logData.trend = stats.currentTrend;
    logData.totalClosedROI = stats.totalClosedROI;
    logData.totalRealizedPNL = stats.totalRealizedPNL;
    
    fullChartHistory.push(logData);
    if (fullChartHistory.length > MAX_PRICE_MEMORY) {
        fullChartHistory.shift();
    }

    return logData;
}

// ==================== CLI PRINT FORMATTING ====================
function printTickToCLI(data) {
    if (stats.lastPrice > 0 && data.price === stats.lastPrice) return;

    const d = new Date(data.time);
    const timeStr = d.getHours().toString().padStart(2,"0") + ":" + 
                    d.getMinutes().toString().padStart(2,"0") + ":" + 
                    d.getSeconds().toString().padStart(2,"0");

    let pColor = colors.reset; 
    let pIcon = "━";
    
    if (stats.lastPrice > 0) {
        if (data.price > stats.lastPrice) { pColor = colors.green; pIcon = "▲"; }
        else if (data.price < stats.lastPrice) { pColor = colors.red; pIcon = "▼"; }
    }
    
    let line = `${colors.gray}[${timeStr}]${colors.reset}  ${pColor}${pIcon}  $${data.price.toFixed(8)}${colors.reset}`;

    if (data.fastEMA > 0) {
        line += `   ${colors.gray}|${colors.reset}   EMA TREND: [Fast: ${colors.cyan}${data.fastEMA.toFixed(8)}${colors.reset} ━ Slow: ${colors.magenta}${data.slowEMA.toFixed(8)}${colors.reset}]`;

        if (data.trend) {
            let uPnlStr = data.unrealizedPNL >= 0 ? `+$${data.unrealizedPNL.toFixed(4)}` : `-$${Math.abs(data.unrealizedPNL).toFixed(4)}`;
            let roiStr = data.roi >= 0 ? `+${data.roi.toFixed(2)}%` : `${data.roi.toFixed(2)}%`;
            let pnlColor = data.unrealizedPNL >= 0 ? colors.green : colors.red;
            let trendColor = data.trend === "BULLISH" ? colors.green : colors.red;

            line += `   ${colors.gray}[${colors.reset}${trendColor}${data.trend}${colors.reset} ${colors.gray}|${colors.reset} Active PNL: ${pnlColor}${uPnlStr} (${roiStr})${colors.reset}${colors.gray}]${colors.reset}`;
        }

        if (data.confirmMsg) {
            line += `   ${colors.gray}${data.confirmMsg.replace(/BULLISH/g, colors.green + "BULLISH" + colors.reset).replace(/BEARISH/g, colors.red + "BEARISH" + colors.reset)}${colors.reset}`;
        }

        if (isLiveStream) {
            let rPnlStr = data.totalRealizedPNL >= 0 ? `+$${data.totalRealizedPNL.toFixed(4)}` : `-$${Math.abs(data.totalRealizedPNL).toFixed(4)}`;
            let totalRoiStr = data.totalClosedROI >= 0 ? `+${data.totalClosedROI.toFixed(2)}%` : `${data.totalClosedROI.toFixed(2)}%`;
            let totalColor = data.totalRealizedPNL >= 0 ? colors.green : colors.red;
            line += `   ${colors.gray}━━━ [Sum Closed PNL: ${totalColor}${rPnlStr} (${totalRoiStr})${colors.reset}${colors.gray}]${colors.reset}`;
        }
    } else {
        line += `   ${colors.gray}[${colors.yellow}CALCULATING EMA BASELINES...${colors.reset}${colors.gray}]${colors.reset}`;
    }

    console.log(line);
}

// ==================== EXPRESS ENDPOINTS ====================

app.get('/api/state', (req, res) => {
    res.json({ config, stats });
});

app.get('/api/history', (req, res) => {
    const limit = parseInt(req.query.limit) || config.chartTicks;
    const data = fullChartHistory.slice(-limit);
    res.json(data);
});

app.post('/api/settings', (req, res) => {
    config = { ...config, ...req.body };
    config.fastPeriod = Math.max(1, config.fastPeriod);
    config.slowPeriod = Math.max(config.fastPeriod + 1, config.slowPeriod); 
    config.chartTicks = Math.max(10, Math.min(2000, config.chartTicks));
    
    // Completely rewrite history and instantly reconstruct EMAs/Trends/Logs mathematically
    replayMemoryWithNewSettings();
    
    console.log(`\n${colors.cyan}[SYSTEM] Live Settings Updated from Web UI! History Recalculated accurately.${colors.reset}\n`);
    res.json({ success: true, config });
});

app.get('/stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    clients.push(res);
    req.on('close', () => { clients = clients.filter(c => c !== res); });
});

function broadcastToWeb(logData) {
    clients.forEach(c => c.write(`data: ${JSON.stringify(logData)}\n\n`));
}

// ==================== WEB HTML DASHBOARD ====================
app.get('/', (req, res) => {
    res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>RDCA Terminal Dashboard</title>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Roboto+Mono:wght@400;500&display=swap" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <style>
            body { font-family: 'Roboto', sans-serif; background: #f5f6fa; color: #212121; margin: 0; display: flex; height: 100vh; overflow: hidden; }
            #sidebar { width: 350px; background: #ffffff; padding: 25px 20px; box-sizing: border-box; border-right: 1px solid #e0e0e0; box-shadow: 2px 0 10px rgba(0,0,0,0.03); overflow-y: auto; z-index: 10; }
            #main { flex-grow: 1; display: flex; flex-direction: column; padding: 25px; background: #f5f6fa; }
            h2 { color: #1976d2; margin-top: 0; font-weight: 500; letter-spacing: 0.5px; }
            h3 { color: #757575; border-bottom: 2px solid #eeeeee; padding-bottom: 8px; font-weight: 500; font-size: 13px; text-transform: uppercase; margin-top: 25px; }
            .form-group { margin-bottom: 15px; }
            label { display: block; color: #616161; margin-bottom: 6px; font-size: 13px; font-weight: 500; }
            input { width: 100%; padding: 10px; background: #ffffff; border: 1px solid #cfd8dc; border-radius: 6px; color: #212121; box-sizing: border-box; font-family: 'Roboto', sans-serif; font-size: 14px; transition: border-color 0.2s, box-shadow 0.2s; }
            input:focus { border-color: #1976d2; outline: none; box-shadow: 0 0 0 3px rgba(25, 118, 210, 0.1); }
            button { width: 100%; padding: 12px; background: #1976d2; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; font-size: 14px; text-transform: uppercase; margin-top: 15px; letter-spacing: 0.5px; box-shadow: 0 2px 5px rgba(25, 118, 210, 0.3); transition: background 0.2s, box-shadow 0.2s; }
            button:hover { background: #1565c0; box-shadow: 0 4px 8px rgba(25, 118, 210, 0.4); }
            .stats-box { background: #ffffff; padding: 18px; margin-bottom: 20px; border-radius: 6px; border-left: 5px solid #1976d2; box-shadow: 0 2px 8px rgba(0,0,0,0.04); font-size: 14px; color: #616161; }
            .stats-val { font-size: 18px; font-weight: 700; color: #1976d2; }
            #chart-container { flex: 1; min-height: 40%; background: #ffffff; border-radius: 8px; border: 1px solid #e0e0e0; box-shadow: 0 4px 12px rgba(0,0,0,0.03); margin-bottom: 20px; padding: 15px; }
            #terminal { background: #ffffff; flex: 1; padding: 15px; overflow-y: auto; border-radius: 8px; border: 1px solid #e0e0e0; box-shadow: 0 4px 12px rgba(0,0,0,0.03); white-space: pre-wrap; font-size: 13px; line-height: 1.6; font-family: 'Roboto Mono', monospace; }
            .t-gray { color: #9e9e9e; } .t-green { color: #388e3c; font-weight: 500; } .t-red { color: #d32f2f; font-weight: 500; } .t-cyan { color: #0097a7; font-weight: 500; } .t-yellow { color: #f57f17; font-weight: 500; } .t-magenta { color: #8e24aa; font-weight: 500; }
        </style>
    </head>
    <body>
        <div id="sidebar">
            <h2>RDCA CONTROL</h2>
            <div class="stats-box">
                <div>Realized PNL: <span id="ui-realized" class="stats-val">$0.0000</span></div>
                <div style="margin-top:10px;">Trend: <span id="ui-trend" class="stats-val">CALCULATING</span></div>
            </div>
            <h3>LIVE SETTINGS</h3>
            <div class="form-group"><label>Contracts (Qty)</label><input type="number" step="0.001" id="c-contracts" /></div>
            <div class="form-group"><label>Leverage</label><input type="number" id="c-lev" /></div>
            <div class="form-group"><label>Fast EMA Period</label><input type="number" id="c-fast" /></div>
            <div class="form-group"><label>Slow EMA Period</label><input type="number" id="c-slow" /></div>
            <div class="form-group"><label>Macro Window (W1)</label><input type="number" id="c-w1" /></div>
            <div class="form-group"><label>Meso Window (W2)</label><input type="number" id="c-w2" /></div>
            <div class="form-group"><label>Micro Window (W3)</label><input type="number" id="c-w3" /></div>
            <div class="form-group"><label>Max Chart Ticks</label><input type="number" id="c-ticks" min="10" max="2000" /></div>
            
            <button onclick="updateSettings()">UPDATE BOT SETTINGS</button>
            <div id="update-msg" style="color:#388e3c; margin-top:12px; text-align:center; font-size: 13px; font-weight: 500; display:none;">Rewinding time... Settings Applied!</div>
        </div>
        
        <div id="main">
            <h2>LIVE MARKET DATA</h2>
            <div id="chart-container"><canvas id="liveChart"></canvas></div>
            <div id="terminal">System Initialized. Loading History...<br><br></div>
        </div>

        <script>
            // --- Chart.js Initialization ---
            const ctx = document.getElementById('liveChart').getContext('2d');
            const liveChart = new Chart(ctx, {
                type: 'line',
                data: { labels: [], datasets: [
                    { label: 'Price Base', data: [], borderColor: '#424242', backgroundColor: 'transparent', borderWidth: 1, pointRadius: 0, tension: 0.1 },
                    { label: 'Fast EMA', data: [], borderColor: '#00acc1', backgroundColor: 'transparent', borderWidth: 1.5, pointRadius: 0, tension: 0.1 },
                    { label: 'Slow EMA', data: [], borderColor: '#8e24aa', backgroundColor: 'transparent', borderWidth: 1.5, pointRadius: 0, tension: 0.1 },
                    { label: 'BULLISH', data: [], borderColor: '#43a047', backgroundColor: 'transparent', borderWidth: 3, pointRadius: 0, tension: 0.1 },
                    { label: 'BEARISH', data: [], borderColor: '#e53935', backgroundColor: 'transparent', borderWidth: 3, pointRadius: 0, tension: 0.1 }
                ]},
                options: { responsive: true, maintainAspectRatio: false, animation: false, scales: { x: { ticks: { color: '#757575' }, grid: { color: '#eeeeee' } }, y: { ticks: { color: '#757575' }, grid: { color: '#eeeeee' } } }, plugins: { legend: { labels: { color: '#424242', font: { family: "'Roboto', sans-serif" } } } } }
            });

            function formatTime(isoString) {
                const d = new Date(isoString);
                return d.getHours().toString().padStart(2,"0") + ":" + d.getMinutes().toString().padStart(2,"0") + ":" + d.getSeconds().toString().padStart(2,"0");
            }

            // HTML Terminal string generator matching exact Node CLI output
            function generateLogLine(data, lastPtPrice) {
                const timeStr = formatTime(data.time);
                let icon = "━"; let colorClass = "t-gray";
                if (lastPtPrice > 0) {
                    if (data.price > lastPtPrice) { icon = "▲"; colorClass = "t-green"; }
                    else if (data.price < lastPtPrice) { icon = "▼"; colorClass = "t-red"; }
                }

                let logLine = \`<span class="t-gray">[\${timeStr}]</span>  <span class="\${colorClass}">\${icon}</span>  $\${data.price.toFixed(8)}\`;
                
                if (data.fastEMA > 0) {
                    logLine += \`   <span class="t-gray">|</span>   EMA TREND: [Fast: <span class="t-cyan">\${data.fastEMA.toFixed(8)}</span> ━ Slow: <span class="t-magenta">\${data.slowEMA.toFixed(8)}</span>]\`;
                    
                    if (data.trend) {
                        let uClass = data.unrealizedPNL >= 0 ? "t-green" : "t-red";
                        let uPnlStr = data.unrealizedPNL >= 0 ? "+$" + data.unrealizedPNL.toFixed(4) : "-$" + Math.abs(data.unrealizedPNL).toFixed(4);
                        let rStr = data.roi >= 0 ? "+" + data.roi.toFixed(2) + "%" : data.roi.toFixed(2) + "%";
                        let tClass = data.trend === "BULLISH" ? "t-green" : "t-red";
                        logLine += \`   <span class="t-gray">[</span><span class="\${tClass}">\${data.trend}</span> <span class="t-gray">| Active PNL: </span><span class="\${uClass}">\${uPnlStr} (\${rStr})</span><span class="t-gray">]</span>\`;
                    }
                    if (data.confirmMsg) { 
                        let formattedMsg = data.confirmMsg.replace(/BULLISH/g, '<span class="t-green">BULLISH</span>').replace(/BEARISH/g, '<span class="t-red">BEARISH</span>');
                        logLine += \`   <span class="t-gray">\${formattedMsg}</span>\`; 
                    }
                    if (data.totalRealizedPNL !== undefined) {
                        let rClass = data.totalRealizedPNL >= 0 ? "t-green" : "t-red";
                        let rPnlStr = data.totalRealizedPNL >= 0 ? "+$" + data.totalRealizedPNL.toFixed(4) : "-$" + Math.abs(data.totalRealizedPNL).toFixed(4);
                        let rRoiStr = data.totalClosedROI >= 0 ? "+" + data.totalClosedROI.toFixed(2) + "%" : data.totalClosedROI.toFixed(2) + "%";
                        logLine += \`   <span class="t-gray">━━━ [Sum Closed PNL: <span class="\${rClass}">\${rPnlStr} (\${rRoiStr})</span>]</span>\`;
                    }
                } else {
                     logLine += \`   <span class="t-gray">[<span class="t-yellow">CALCULATING EMA BASELINES...</span>]</span>\`;
                }
                return logLine;
            }

            async function initDashboard() {
                const stateRes = await fetch('/api/state');
                const stateData = await stateRes.json();

                document.getElementById('c-contracts').value = stateData.config.contracts;
                document.getElementById('c-fast').value = stateData.config.fastPeriod;
                document.getElementById('c-slow').value = stateData.config.slowPeriod;
                document.getElementById('c-w1').value = stateData.config.window1;
                document.getElementById('c-w2').value = stateData.config.window2;
                document.getElementById('c-w3').value = stateData.config.window3;
                document.getElementById('c-lev').value = stateData.config.leverage;
                document.getElementById('c-ticks').value = stateData.config.chartTicks || 60;

                const tEl = document.getElementById('ui-trend');
                if (stateData.stats.currentTrend) {
                    tEl.innerText = stateData.stats.currentTrend;
                    tEl.className = stateData.stats.currentTrend === 'BULLISH' ? "t-green" : "t-red";
                }

                await loadChartHistory(stateData.config.chartTicks || 60);
                connectLiveStream();
            }

            let lastRenderedPrice = 0;

            async function loadChartHistory(limit) {
                const histRes = await fetch('/api/history?limit=' + limit);
                const histData = await histRes.json();

                // Clear Chart Datasets
                liveChart.data.labels = []; 
                liveChart.data.datasets[0].data = []; 
                liveChart.data.datasets[1].data = []; 
                liveChart.data.datasets[2].data = [];
                liveChart.data.datasets[3].data = [];
                liveChart.data.datasets[4].data = [];

                // Clear UI Terminal so it visually repaints from scratch
                const term = document.getElementById('terminal');
                term.innerHTML = "";
                lastRenderedPrice = 0;

                histData.forEach(pt => {
                    const timeStr = formatTime(pt.time);
                    liveChart.data.labels.push(timeStr);
                    liveChart.data.datasets[0].data.push(pt.price);
                    liveChart.data.datasets[1].data.push(pt.fastEMA);
                    liveChart.data.datasets[2].data.push(pt.slowEMA);

                    // Push price to the specific trend line to color it Green/Red based on active trend
                    liveChart.data.datasets[3].data.push(pt.trend === 'BULLISH' ? pt.price : null);
                    liveChart.data.datasets[4].data.push(pt.trend === 'BEARISH' ? pt.price : null);

                    if (lastRenderedPrice > 0 && pt.price === lastRenderedPrice) return;

                    let logLine = generateLogLine(pt, lastRenderedPrice);
                    term.innerHTML += logLine + "<br>";
                    
                    lastRenderedPrice = pt.price;
                });
                liveChart.update();
                term.scrollTop = term.scrollHeight;
                
                // Update Top UI Display
                if(histData.length > 0) {
                    const lastData = histData[histData.length - 1];
                    updateTopStats(lastData);
                }
            }
            
            function updateTopStats(data) {
                const rPnlEl = document.getElementById('ui-realized');
                let rPnlStr = data.totalRealizedPNL >= 0 ? "+$" + data.totalRealizedPNL.toFixed(4) : "-$" + Math.abs(data.totalRealizedPNL).toFixed(4);
                let rRoiStr = data.totalClosedROI >= 0 ? "+" + data.totalClosedROI.toFixed(2) + "%" : data.totalClosedROI.toFixed(2) + "%";
                
                rPnlEl.innerText = \`\${rPnlStr} (\${rRoiStr})\`;
                rPnlEl.className = data.totalRealizedPNL >= 0 ? "stats-val t-green" : "stats-val t-red";
                
                if (data.trend) {
                    const tEl = document.getElementById('ui-trend');
                    tEl.innerText = data.trend;
                    tEl.className = data.trend === 'BULLISH' ? "stats-val t-green" : "stats-val t-red";
                }
            }

            function updateSettings() {
                const payload = {
                    contracts: parseFloat(document.getElementById('c-contracts').value) || 1,
                    fastPeriod: parseInt(document.getElementById('c-fast').value),
                    slowPeriod: parseInt(document.getElementById('c-slow').value),
                    window1: parseInt(document.getElementById('c-w1').value),
                    window2: parseInt(document.getElementById('c-w2').value),
                    window3: parseInt(document.getElementById('c-w3').value),
                    leverage: parseInt(document.getElementById('c-lev').value),
                    chartTicks: parseInt(document.getElementById('c-ticks').value)
                };
                
                // POST settings, wait for backend to rewrite history mathematically, then refetch history!
                fetch('/api/settings', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) })
                .then(() => {
                    loadChartHistory(payload.chartTicks); // Repaints Terminal dynamically
                    let msg = document.getElementById('update-msg');
                    msg.style.display = 'block'; setTimeout(() => msg.style.display = 'none', 3000);
                });
            }

            function connectLiveStream() {
                const source = new EventSource('/stream');
                source.onmessage = function(event) {
                    const data = JSON.parse(event.data);
                    
                    updateTopStats(data);

                    const timeStr = formatTime(data.time);
                    liveChart.data.labels.push(timeStr);
                    liveChart.data.datasets[0].data.push(data.price);
                    liveChart.data.datasets[1].data.push(data.fastEMA || null);
                    liveChart.data.datasets[2].data.push(data.slowEMA || null);

                    // Push price to specific trend line dataset
                    liveChart.data.datasets[3].data.push(data.trend === 'BULLISH' ? data.price : null);
                    liveChart.data.datasets[4].data.push(data.trend === 'BEARISH' ? data.price : null);
                    
                    let maxTicks = parseInt(document.getElementById('c-ticks').value) || 60;
                    while (liveChart.data.labels.length > maxTicks) {
                        liveChart.data.labels.shift(); 
                        liveChart.data.datasets[0].data.shift(); 
                        liveChart.data.datasets[1].data.shift(); 
                        liveChart.data.datasets[2].data.shift();
                        liveChart.data.datasets[3].data.shift();
                        liveChart.data.datasets[4].data.shift();
                    }
                    liveChart.update();

                    if (lastRenderedPrice > 0 && data.price === lastRenderedPrice) return;
                    
                    let logLine = generateLogLine(data, lastRenderedPrice);
                    const term = document.getElementById('terminal');
                    term.innerHTML += logLine + "<br>";
                    term.scrollTop = term.scrollHeight;

                    lastRenderedPrice = data.price;
                };
            }

            initDashboard();
        </script>
    </body>
    </html>
    `);
});

// ==================== WEBSOCKET SCRAPER + BOT EXECUTION ENGINE ====================
async function startLiveStreamAndScraper() {
    console.log(`\n${colors.cyan}--- STARTING WEBSOCKET PRICE SCRAPER & BOT STREAM ---${colors.reset}`);
    let marketsLoaded = false;
    
    // 1. Load Markets into Pro Websocket Instance
    while (!marketsLoaded) { 
        try { 
            await priceFeed.loadMarkets(); 
            marketsLoaded = true; 
            console.log(`${colors.green}✅ Markets loaded. Starting HTX live stream for ${FEED_SYMBOL}...${colors.reset}\n`);
        } catch (e) { 
            console.error(`${colors.red}🚨 Market load failed, retrying in 5s... ${e.message}${colors.reset}`);
            await new Promise(r => setTimeout(r, 5000)); 
        } 
    }
    
    let lastHistorySave = 0;

    // 2. Continuous Live Watch Loop
    while (true) {
        try {
            // watchTicker fetches live data instantly as the exchange pushes updates
            const ticker = await priceFeed.watchTicker(FEED_SYMBOL); 
            
            // Calculate mid price based on orderbook bid/ask
            const mid = ((ticker.bid || ticker.last) + (ticker.ask || ticker.last)) / 2;
            const now = Date.now();
            
            // 3. Save to MongoDB & Run Bot Logic (Throttled based on your SAVE_INTERVAL_MS)
            if (now - lastHistorySave >= SAVE_INTERVAL_MS) { 
                
                // --- SCRAPER DB SAVE ---
                await ChartDataModel.create({ htxMid: mid });
                
                // --- TRADING BOT LOGIC TRIGGER ---
                if (isLiveStream && mid !== stats.lastPrice) {
                    let logData = thinkAndTrade(mid, now);
                    broadcastToWeb(logData);
                    printTickToCLI(logData);
                    stats.lastPrice = mid;
                }
                
                lastHistorySave = now; 
            }

        } catch (e) { 
            console.error(`${colors.red}🚨 Stream disconnected or errored: ${e.message}${colors.reset}`);
            // Wait 2 seconds before attempting to reconnect/resume
            await new Promise(r => setTimeout(r, 2000)); 
        }
    }
}

// ==================== MAIN SCRIPT INITIALIZATION ====================
async function startBot() {
    console.clear();
    console.log(`${colors.cyan}===========================================${colors.reset}`);
    console.log(`${colors.cyan}    RDCA TERMINAL (SMART EMA TREND FOLLOWER)${colors.reset}`);
    console.log(`${colors.cyan}===========================================${colors.reset}\n`);

    process.stdout.write(`${colors.gray}Connecting to Database... ${colors.reset}`);
    
    try {
        await mongoose.connect(MONGO_URI);
        console.log(`${colors.green}Connected! ✅${colors.reset}\n`);
    } catch (err) {
        console.log(`${colors.red}Connection Failed! 🚨${colors.reset}\n`, err.message);
        process.exit(1);
    }

    console.log(`${colors.gray}Bot is analyzing historical structures...${colors.reset}\n`);

    const initialData = await ChartDataModel.find().sort({ timestamp: -1 }).limit(MAX_PRICE_MEMORY);
    const sortedData = initialData.reverse(); 

    const startIndexToPrint = Math.max(0, sortedData.length - config.chartTicks);

    sortedData.forEach((doc, index) => {
        let logData = thinkAndTrade(doc.htxMid, doc.timestamp);
        
        if (index >= startIndexToPrint) {
            printTickToCLI(logData);
        }
        
        stats.lastPrice = doc.htxMid; 
    });

    console.log(`\n${colors.cyan}--- WEB SERVER STARTED ---${colors.reset}`);
    app.listen(PORT, () => {
        console.log(`${colors.green}🟢 BOT DASHBOARD LIVE! Open http://localhost:${PORT} in your browser${colors.reset}\n`);
    });

    console.log(`${colors.cyan}--- STREAMING NEW LIVE TICKS ONWARDS ---${colors.reset}\n`);
    isLiveStream = true; 

    // FIRE IMMEDIATE ORDER ON ESTABLISHED TREND ONCE BOT ENTERS LIVE STREAM MODE
    if (stats.currentTrend !== null) {
        executeHitbtcReversal(stats.currentTrend);
    }

    // DIRECT HTX WEBSOCKET SCRAPER (Replaces the old setInterval method)
    await startLiveStreamAndScraper();
}

startBot();
