const fs = require('fs');
const dotenv = require('dotenv');
const ccxt = require('ccxt');
const express = require('express');
const mongoose = require('mongoose');
const https = require('https');

dotenv.config();

function loadEnvKeys(filePath) {
    if (fs.existsSync(filePath)) {
        const parsed = dotenv.parse(fs.readFileSync(filePath));
        return { key: parsed.HTX_API_KEY, secret: parsed.HTX_SECRET };
    }
    return { key: null, secret: null };
}

const keepAliveAgent = new https.Agent({ keepAlive: true, maxSockets: 100, keepAliveMsecs: 30000 });

// ==================== MONGODB SETUP ====================
// ⚠️ SECURITY WARNING: Never hardcode passwords in shared code. Use .env!
const MONGO_URI = process.env.MONGO_URI || "mongodb+srv://web88888888888888_db_user:ZETrZHXzaxoekjkm@clusterweb8888.l0rv6hv.mongodb.net/botdb?appName=Clusterweb8888";

mongoose.connect(MONGO_URI)
    .then(() => console.log('✅ MongoDB Connected Successfully'))
    .catch(err => console.error('🚨 MongoDB Connection Error:', err));

const ChartModel = mongoose.model('ChartData', new mongoose.Schema({
    timestamp: { type: Date, default: Date.now }, binanceMid: Number, htxMid: Number, zigZagTrend: Number, extremaVal: Number
}));

const SettingModel = mongoose.model('BotSetting', new mongoose.Schema({
    workerId: { type: Number, unique: true }, liveTradingEnabled: { type: Boolean, default: false }
}));

// ==================== BASE CONFIGURATION ====================
const CUSTOM_PORT = process.env.PORT || 3000;

const BASE_CONFIG = {
    symbol: 'TIA/USDT:USDT',      
    leverage: 10,                 
    contracts: 1,                 
    marginMode: 'cross',          
    fees: { taker: 0 }, 
    zigZagThresholdPct: 0.25,     
    thresholds: {
        slRoiPct: -200.0,           
        tpCooldownMs: 15000        
    }
};

// ==================== GLOBAL MARKET ORACLE ====================
const globalMarketData = { 
    binance: { bid: 0, ask: 0, mid: 0, timestamp: 0 }, htx: { bid: 0, ask: 0, mid: 0, prevMid: 0, timestamp: 0 } 
};

const globalMetrics = { 
    currentDeviation: 0, trendMovePct: 0, binanceTrend: 'WAITING', targetSide: 'WAITING', zigZagTrend: 0, currentExtremaVal: null, lastLockedHigh: null, lastLockedLow: null, smoothedThresholdLine: null
};

const publicBinance = new ccxt.pro.binance({ options: { defaultType: 'swap' } });
const publicHtx = new ccxt.pro.htx({ options: { defaultType: 'swap', defaultSubType: 'linear' } });

// ==================== ADVANCED METRICS ENGINE ====================
class PerformanceMetrics {
    constructor() {
        this.trades = []; this.totalNetPnl = 0; this.totalFees = 0;
        this.totalRoiPct = 0; this.wins = 0; this.losses = 0; this.winRate = 0; this.consecutiveLosses = 0; 
        this.totalTradesCount = 0; // ⚡ FIXED: Added raw counter for the UI rendering fix
    }
    recordTrade(trade) {
        this.totalTradesCount++; // ⚡ FIXED: Increment raw counter
        this.trades.push({ ...trade, timestamp: Date.now() });
        if (this.trades.length > 1000) this.trades.shift(); 
        
        this.totalNetPnl += trade.netPnl; this.totalFees += trade.feeCost;
        this.totalRoiPct += trade.roiPct || 0; 
        
        if (trade.netPnl > 0) { this.wins++; this.consecutiveLosses = 0; } else { this.losses++; this.consecutiveLosses++; }
        this.winRate = this.trades.length ? (this.wins / this.trades.length) : 0;
    }
}

// ==================== WORKER INSTANCE ====================
class TradeInstance {
    constructor(id, name, config) {
        this.id = id; this.name = name; this.config = config; this.startTime = Date.now();
        this.htx = new ccxt.pro.htx({
            apiKey: this.config.apiKey, secret: this.config.apiSecret, agent: keepAliveAgent, enableRateLimit: false,
            options: { defaultType: 'swap', defaultSubType: 'linear', defaultMarginMode: this.config.marginMode, positionMode: 'hedged' }
        });
        this.activePositions = []; this.metrics = new PerformanceMetrics();
        this.isTrading = false; this.cooldownUntil = 0; this.liveTradingEnabled = false; this.currentTrackedTrend = null; 
    }
    
    async loadDbSettings() {
        try {
            let setting = await SettingModel.findOne({ workerId: this.id });
            if (!setting) setting = await SettingModel.create({ workerId: this.id, liveTradingEnabled: false });
            this.liveTradingEnabled = setting.liveTradingEnabled;
        } catch (err) { console.error(`[Worker ${this.id}] DB Setting Load Error:`, err.message); }
    }

    async initialize() {
        if (!this.config.apiKey || !this.config.apiSecret) return;
        try {
            await this.htx.loadMarkets();
            const positions = await this.htx.fetchPositions([this.config.symbol]);
            const openPos = positions.find(p => p.contracts > 0);
            
            if (openPos) {
                this.activePositions.push({
                    id: Date.now(), side: openPos.side, entryPrice: openPos.entryPrice, 
                    contracts: openPos.contracts, size: openPos.contracts * openPos.entryPrice, exchangeROI: openPos.percentage || 0, entryTime: Date.now(), isPaper: false
                });
                this.currentTrackedTrend = openPos.side;
                if (globalMetrics.targetSide === 'WAITING') { globalMetrics.targetSide = openPos.side; globalMetrics.binanceTrend = openPos.side === 'long' ? 'UP' : 'DOWN'; globalMetrics.zigZagTrend = openPos.side === 'long' ? 1 : -1; }
            }
            await this.htx.setLeverage(this.config.leverage, this.config.symbol, { marginMode: this.config.marginMode }).catch(()=>{});
            this.startExchangeROISync();
        } catch (error) { console.error(`[Worker ${this.id}] Init error:`, error.message); }
    }

    async checkExits() {
        if (this.isTrading || this.activePositions.length === 0) return;
        const pos = this.activePositions[0];
        
        let currentPrice = pos.side === 'long' ? globalMarketData.htx.bid : globalMarketData.htx.ask;
        if (!currentPrice || currentPrice === 0) currentPrice = globalMarketData.binance.mid;
        if (!currentPrice) return;

        const grossPnlPercent = pos.side === 'long' ? ((currentPrice - pos.entryPrice) / pos.entryPrice) * 100 : ((pos.entryPrice - currentPrice) / pos.entryPrice) * 100;
        const grossPnlUsd = (grossPnlPercent / 100) * pos.size; 
        const feeCostUsd = pos.size * (this.config.fees.taker * 2);
        const netPnlUsd = grossPnlUsd - feeCostUsd; 
        const netRoiPct = (netPnlUsd / (pos.size / this.config.leverage)) * 100;

        if (netRoiPct <= this.config.thresholds.slRoiPct) {
            this.forceClosePosition();
        }
    }

    async syncState(targetSide) {
        if (this.isTrading || targetSide === 'WAITING') return;
        
        const currentPos = this.activePositions.length > 0 ? this.activePositions[0] : null;
        if (currentPos && currentPos.side === targetSide) { this.currentTrackedTrend = targetSide; return; }
        if (!currentPos && this.currentTrackedTrend === targetSide && Date.now() < this.cooldownUntil) return;
        
        this.isTrading = true;
        this.currentTrackedTrend = targetSide; 

        try {
            const isPaper = !this.liveTradingEnabled;
            const orderSide = targetSide === 'long' ? 'buy' : 'sell';
            const closeSide = currentPos ? (currentPos.side === 'long' ? 'sell' : 'buy') : null;
            const contracts = this.config.contracts;

            const snapPos = currentPos ? { ...currentPos } : null;
            this.activePositions = []; 

            if (isPaper) {
                if (snapPos) {
                    let currentPrice = snapPos.side === 'long' ? globalMarketData.htx.bid : globalMarketData.htx.ask;
                    const grossPnlPercent = snapPos.side === 'long' ? ((currentPrice - snapPos.entryPrice) / snapPos.entryPrice) * 100 : ((snapPos.entryPrice - currentPrice) / snapPos.entryPrice) * 100;
                    const grossPnlUsd = (grossPnlPercent / 100) * snapPos.size; const feeCostUsd = snapPos.size * (this.config.fees.taker * 2);
                    this.metrics.recordTrade({ side: snapPos.side, entryPrice: snapPos.entryPrice, exitPrice: currentPrice, netPnl: grossPnlUsd - feeCostUsd, feeCost: feeCostUsd, roiPct: ((grossPnlUsd - feeCostUsd) / (snapPos.size / this.config.leverage)) * 100 });
                }
                let executionPrice = targetSide === 'long' ? globalMarketData.htx.ask : globalMarketData.htx.bid;
                this.activePositions = [{ id: Date.now(), side: targetSide, entryPrice: executionPrice, contracts: contracts, size: contracts * executionPrice, entryTime: Date.now(), exchangeROI: 0, isPaper }];
                this.isTrading = false;
            } else {
                const apiTasks = [];
                if (closeSide) {
                    // ⚡ FIXED: Prevent an open error from crashing the successful close memory
                    apiTasks.push(this.htx.createMarketOrder(this.config.symbol, closeSide, snapPos.contracts, undefined, { reduceOnly: true, offset: 'close', marginMode: this.config.marginMode, lever_rate: this.config.leverage }).catch(e => { console.error(`[Worker ${this.id}] Close Error:`, e.message); return null; }));
                } else { apiTasks.push(Promise.resolve(null)); }
                
                apiTasks.push(this.htx.createMarketOrder(this.config.symbol, orderSide, contracts, undefined, { offset: 'open', marginMode: this.config.marginMode, lever_rate: this.config.leverage }).catch(e => { console.error(`[Worker ${this.id}] Open Error:`, e.message); return null; }));

                Promise.all(apiTasks).then(async ([closeRes, openRes]) => {
                    await new Promise(r => setTimeout(r, 500)); 

                    let realExitPrice = closeSide === 'sell' ? globalMarketData.htx.bid : globalMarketData.htx.ask;
                    let realEntryPrice = orderSide === 'buy' ? globalMarketData.htx.ask : globalMarketData.htx.bid;

                    if (closeRes && closeRes.id) {
                        try { const cOrder = await this.htx.fetchOrder(closeRes.id, this.config.symbol); if (cOrder && cOrder.average) realExitPrice = cOrder.average; } catch(e){}
                    }
                    if (openRes && openRes.id) {
                        try { const oOrder = await this.htx.fetchOrder(openRes.id, this.config.symbol); if (oOrder && oOrder.average) realEntryPrice = oOrder.average; } catch(e){}
                    }

                    if (snapPos) {
                        const grossPnlPercent = snapPos.side === 'long' ? ((realExitPrice - snapPos.entryPrice) / snapPos.entryPrice) * 100 : ((snapPos.entryPrice - realExitPrice) / snapPos.entryPrice) * 100;
                        const grossPnlUsd = (grossPnlPercent / 100) * snapPos.size; 
                        const feeCostUsd = snapPos.size * (this.config.fees.taker * 2);
                        const netPnlUsd = grossPnlUsd - feeCostUsd; 
                        const netRoiPct = (netPnlUsd / (snapPos.size / this.config.leverage)) * 100;

                        this.metrics.recordTrade({ side: snapPos.side, entryPrice: snapPos.entryPrice, exitPrice: realExitPrice, netPnl: netPnlUsd, feeCost: feeCostUsd, roiPct: netRoiPct });
                    }

                    this.activePositions = [{ id: Date.now(), side: targetSide, entryPrice: realEntryPrice, contracts: contracts, size: contracts * realEntryPrice, entryTime: Date.now(), exchangeROI: 0, isPaper: false }];
                    this.isTrading = false;
                }).catch(apiErr => { 
                    console.error(`[Worker ${this.id}] Background HTX Execution Error:`, apiErr.message); 
                    this.activePositions = []; 
                    this.isTrading = false;
                });
            }
        } catch (error) { console.error(`[Worker ${this.id}] Sync Error:`, error.message); this.activePositions = []; this.isTrading = false; }
    }

    async forceClosePosition() {
        if (this.isTrading || this.activePositions.length === 0) return;
        const snapPos = { ...this.activePositions[0] };
        
        this.isTrading = true;
        // ⚡ FIXED: Removed this.activePositions = [] from here to prevent premature position memory loss on failure

        try {
            const closeSide = snapPos.side === 'long' ? 'sell' : 'buy';

            if (!snapPos.isPaper) {
                this.htx.createMarketOrder(this.config.symbol, closeSide, snapPos.contracts, undefined, { 
                    reduceOnly: true, offset: 'close', marginMode: this.config.marginMode, lever_rate: this.config.leverage 
                }).then(async closeRes => {
                    this.activePositions = []; // ⚡ FIXED: Clear only after API confirmation
                    await new Promise(r => setTimeout(r, 500));
                    let realExitPrice = closeSide === 'sell' ? globalMarketData.htx.bid : globalMarketData.htx.ask;
                    
                    if (closeRes && closeRes.id) {
                        try { const cOrder = await this.htx.fetchOrder(closeRes.id, this.config.symbol); if (cOrder && cOrder.average) realExitPrice = cOrder.average; } catch(e){}
                    }

                    const grossPnlPercent = snapPos.side === 'long' ? ((realExitPrice - snapPos.entryPrice) / snapPos.entryPrice) * 100 : ((snapPos.entryPrice - realExitPrice) / snapPos.entryPrice) * 100;
                    const grossPnlUsd = (grossPnlPercent / 100) * snapPos.size; const feeCostUsd = snapPos.size * (this.config.fees.taker * 2);
                    
                    this.metrics.recordTrade({ side: snapPos.side, entryPrice: snapPos.entryPrice, exitPrice: realExitPrice, netPnl: grossPnlUsd - feeCostUsd, feeCost: feeCostUsd, roiPct: ((grossPnlUsd - feeCostUsd) / (snapPos.size / this.config.leverage)) * 100 });
                    this.cooldownUntil = Date.now() + this.config.thresholds.tpCooldownMs; 
                    this.isTrading = false;
                }).catch(err => { console.error(`[Worker ${this.id}] Force Close Error:`, err.message); this.isTrading = false; });
            } else {
                this.activePositions = []; // ⚡ FIXED: For paper trading, clear here
                let currentPrice = snapPos.side === 'long' ? globalMarketData.htx.bid : globalMarketData.htx.ask;
                const grossPnlPercent = snapPos.side === 'long' ? ((currentPrice - snapPos.entryPrice) / snapPos.entryPrice) * 100 : ((snapPos.entryPrice - currentPrice) / snapPos.entryPrice) * 100;
                const grossPnlUsd = (grossPnlPercent / 100) * snapPos.size; const feeCostUsd = snapPos.size * (this.config.fees.taker * 2);
                this.metrics.recordTrade({ side: snapPos.side, entryPrice: snapPos.entryPrice, exitPrice: currentPrice, netPnl: grossPnlUsd - feeCostUsd, feeCost: feeCostUsd, roiPct: ((grossPnlUsd - feeCostUsd) / (snapPos.size / this.config.leverage)) * 100 });
                this.cooldownUntil = Date.now() + this.config.thresholds.tpCooldownMs; 
                this.isTrading = false;
            }
        } catch (error) { console.error(`[Worker ${this.id}] Force Close Error:`, error.message); this.isTrading = false; }
    }
    
    startExchangeROISync() {
        setInterval(() => {
            if (this.activePositions.length === 0 || this.isTrading) return;
            const pos = this.activePositions[0];
            if (pos.isPaper) {
                const markPrice = globalMarketData.htx.mid || globalMarketData.binance.mid; 
                if (markPrice && pos.entryPrice) {
                    const grossPnlPercent = pos.side === 'long' ? ((markPrice - pos.entryPrice) / pos.entryPrice) * 100 : ((pos.entryPrice - markPrice) / pos.entryPrice) * 100;
                    const grossPnlUsd = (grossPnlPercent / 100) * pos.size; const feeCostUsd = pos.size * (this.config.fees.taker * 2);
                    pos.exchangeROI = ((grossPnlUsd - feeCostUsd) / (pos.size / this.config.leverage)) * 100;
                }
            }
        }, 300);

        setInterval(async () => {
            if (this.isTrading || !this.liveTradingEnabled) return;
            try {
                const positions = await this.htx.fetchPositions([this.config.symbol]);
                if (!positions) return; 
                const activeExchangePos = positions.find(p => p.contracts > 0);
                
                if (this.activePositions.length > 0) {
                    const pos = this.activePositions[0];
                    if (!activeExchangePos && (Date.now() - pos.entryTime > 20000)) { this.activePositions = []; } 
                    else if (activeExchangePos && activeExchangePos.side === pos.side) {
                        pos.exchangeROI = activeExchangePos.percentage || 0;
                        if (activeExchangePos.entryPrice && pos.entryTime < Date.now() - 3000) pos.entryPrice = activeExchangePos.entryPrice;
                    }
                } else if (activeExchangePos) {
                    this.activePositions.push({
                        id: Date.now(), side: activeExchangePos.side, entryPrice: activeExchangePos.entryPrice, 
                        contracts: activeExchangePos.contracts, size: activeExchangePos.contracts * activeExchangePos.entryPrice, exchangeROI: activeExchangePos.percentage || 0, entryTime: Date.now(), isPaper: false
                    });
                }
            } catch (error) { }
        }, 2000);
    }

    getExportData() {
        return {
            id: this.id, name: this.name, config: this.config,
            botInfo: { uptime: Math.floor((Date.now() - this.startTime) / 1000), cooldownUntil: this.cooldownUntil, liveTradingEnabled: this.liveTradingEnabled },
            metrics: this.metrics, activePositions: this.activePositions, marketData: { binance: globalMarketData.binance, htx: globalMarketData.htx }, leadLagStats: globalMetrics 
        };
    }
}

// ==================== ZIGZAG BACKEND ENGINE ====================
let lastDbChartSave = 0; 
async function evaluateTrendTriggers() {
    const now = Date.now();
    if ((now - globalMarketData.binance.timestamp) > 5000) return;
    if (globalMarketData.binance.mid > 0) {
        if (globalMarketData.htx.mid > 0) globalMetrics.currentDeviation = ((globalMarketData.binance.mid - globalMarketData.htx.mid) / globalMarketData.htx.mid) * 100;
        const currentTick = globalMarketData.binance.mid;

        if (globalMetrics.currentExtremaVal === null) { globalMetrics.currentExtremaVal = currentTick; } 
        else if (globalMetrics.targetSide === 'WAITING') {
            if (currentTick > globalMetrics.currentExtremaVal) { globalMetrics.zigZagTrend = 1; globalMetrics.targetSide = 'long'; globalMetrics.binanceTrend = 'UP'; globalMetrics.currentExtremaVal = currentTick; } 
            else if (currentTick < globalMetrics.currentExtremaVal) { globalMetrics.zigZagTrend = -1; globalMetrics.targetSide = 'short'; globalMetrics.binanceTrend = 'DOWN'; globalMetrics.currentExtremaVal = currentTick; }
        } else {
            const changeFromExtrema = ((currentTick - globalMetrics.currentExtremaVal) / globalMetrics.currentExtremaVal) * 100;
            globalMetrics.trendMovePct = changeFromExtrema; 
            
            if (globalMetrics.zigZagTrend === -1 && globalMetrics.lastLockedHigh !== null && currentTick > globalMetrics.lastLockedHigh) {
                globalMetrics.lastLockedLow = globalMetrics.currentExtremaVal; globalMetrics.zigZagTrend = 1; globalMetrics.targetSide = 'long'; globalMetrics.binanceTrend = 'UP'; globalMetrics.currentExtremaVal = currentTick;
            } else if (globalMetrics.zigZagTrend === 1 && globalMetrics.lastLockedLow !== null && currentTick < globalMetrics.lastLockedLow) {
                globalMetrics.lastLockedHigh = globalMetrics.currentExtremaVal; globalMetrics.zigZagTrend = -1; globalMetrics.targetSide = 'short'; globalMetrics.binanceTrend = 'DOWN'; globalMetrics.currentExtremaVal = currentTick;
            } else if (globalMetrics.zigZagTrend === 1) { 
                if (currentTick >= globalMetrics.currentExtremaVal) { globalMetrics.currentExtremaVal = currentTick; } 
                else if (changeFromExtrema <= -BASE_CONFIG.zigZagThresholdPct) { globalMetrics.lastLockedHigh = globalMetrics.currentExtremaVal; globalMetrics.zigZagTrend = -1; globalMetrics.currentExtremaVal = currentTick; globalMetrics.binanceTrend = 'DOWN'; globalMetrics.targetSide = 'short'; }
            } else if (globalMetrics.zigZagTrend === -1) { 
                if (currentTick <= globalMetrics.currentExtremaVal) { globalMetrics.currentExtremaVal = currentTick; } 
                else if (changeFromExtrema >= BASE_CONFIG.zigZagThresholdPct) { globalMetrics.lastLockedLow = globalMetrics.currentExtremaVal; globalMetrics.zigZagTrend = 1; globalMetrics.currentExtremaVal = currentTick; globalMetrics.binanceTrend = 'UP'; globalMetrics.targetSide = 'long'; }
            }
        }

        if (now - lastDbChartSave > 1000) {
            lastDbChartSave = now;
            ChartModel.create({ binanceMid: globalMarketData.binance.mid, htxMid: globalMarketData.htx.mid || globalMarketData.binance.mid, zigZagTrend: globalMetrics.zigZagTrend, extremaVal: globalMetrics.currentExtremaVal }).catch(() => {}); 
        }

        if (globalMetrics.currentExtremaVal !== null) {
            const ZIGZAG_DECIMAL = BASE_CONFIG.zigZagThresholdPct / 100;
            let rawThresholdLine = null;
            if (globalMetrics.zigZagTrend === 1) rawThresholdLine = globalMetrics.currentExtremaVal * (1 - ZIGZAG_DECIMAL);
            else if (globalMetrics.zigZagTrend === -1) rawThresholdLine = globalMetrics.currentExtremaVal * (1 + ZIGZAG_DECIMAL);

            if (rawThresholdLine !== null) {
                if (globalMetrics.smoothedThresholdLine === null) {
                    globalMetrics.smoothedThresholdLine = rawThresholdLine;
                } else {
                    const diff = rawThresholdLine - globalMetrics.smoothedThresholdLine;
                    if (Math.abs(diff) > 0.002 || Math.abs(diff) > (globalMetrics.currentExtremaVal * ZIGZAG_DECIMAL * 0.5)) {
                        globalMetrics.smoothedThresholdLine = rawThresholdLine;
                    }
                }

                let currentThresholdLine = globalMetrics.smoothedThresholdLine;

                if (globalMetrics.lastThresholdLineVal !== undefined && globalMetrics.lastThresholdLineVal !== null) {
                    const moveDiff = currentThresholdLine - globalMetrics.lastThresholdLineVal;
                    const isFlip = Math.abs(moveDiff) > (globalMetrics.currentExtremaVal * ZIGZAG_DECIMAL * 0.5);
                    
                    if (!isFlip && Math.abs(moveDiff) > 0) {
                        if (moveDiff > 0) {
                            globalMetrics.targetSide = 'long';
                            globalMetrics.binanceTrend = 'UP';
                        } else if (moveDiff < 0) {
                            globalMetrics.targetSide = 'short';
                            globalMetrics.binanceTrend = 'DOWN';
                        }
                    }
                }
                globalMetrics.lastThresholdLineVal = currentThresholdLine;
            }
        }

        if (globalMetrics.targetSide !== 'WAITING') {
            engines.forEach(engine => engine.syncState(globalMetrics.targetSide).catch(e => console.error(e)));
        }
    }
}

// ==================== EVENT-DRIVEN MARKET STREAMS ====================
async function startMasterStreams() {
    let marketsLoaded = false;
    while (!marketsLoaded) {
        try { await Promise.all([publicBinance.loadMarkets(), publicHtx.loadMarkets()]); marketsLoaded = true; } 
        catch (error) { await new Promise(r => setTimeout(r, 5000)); }
    }

    (async function streamBinance() {
        let lastMid = 0;
        while (true) {
            try {
                const ticker = await publicBinance.watchTicker(BASE_CONFIG.symbol);
                const mid = ((ticker.bid || ticker.last) + (ticker.ask || ticker.last)) / 2;
                if (mid !== lastMid) { globalMarketData.binance = { bid: ticker.bid, ask: ticker.ask, mid, timestamp: Date.now() }; await evaluateTrendTriggers(); lastMid = mid; }
            } catch (error) { await new Promise(r => setTimeout(r, 2000)); }
        }
    })();
    
    (async function streamHTX() {
        let currentMid = 0; let previousMid = 0;
        while (true) {
            try {
                const ticker = await publicHtx.watchTicker(BASE_CONFIG.symbol);
                const mid = ((ticker.bid || ticker.last) + (ticker.ask || ticker.last)) / 2;
                if (currentMid !== 0 && mid !== currentMid) previousMid = currentMid;
                currentMid = mid;
                globalMarketData.htx = { bid: ticker.bid, ask: ticker.ask, mid: currentMid, prevMid: previousMid || currentMid, timestamp: Date.now() };
                engines.forEach(engine => engine.checkExits().catch(e => console.error(e)));
            } catch (error) { await new Promise(r => setTimeout(r, 2000)); }
        }
    })();
}

// ==================== INSTANCE INIT ====================
const engines = []; let envIndex = 1;
while (fs.existsSync(`./.env${envIndex}`)) {
    const keys = loadEnvKeys(`./.env${envIndex}`);
    if (!keys.key) { keys.key = process.env.HTX_API_KEY; keys.secret = process.env.HTX_SECRET; }
    const config = JSON.parse(JSON.stringify(BASE_CONFIG)); config.apiKey = keys.key; config.apiSecret = keys.secret;
    engines.push(new TradeInstance(envIndex - 1, `Worker ${envIndex}`, config)); envIndex++;
}

if (engines.length === 0) {
    const config = JSON.parse(JSON.stringify(BASE_CONFIG)); config.apiKey = process.env.HTX_API_KEY; config.apiSecret = process.env.HTX_SECRET;
    engines.push(new TradeInstance(0, 'Worker 1', config));
}

// ==================== CRASH PREVENTION ====================
process.on('uncaughtException', (err) => console.error('\n🚨 FATAL CRASH:', err.message));
process.on('unhandledRejection', (reason, promise) => { if (reason && reason.message && !reason.message.includes('fetch failed')) console.error('\n⚠️ PROMISE REJECTION:', reason); });

// ==================== EXPRESS SERVER & UI ====================
const app = express();
app.get('/api/data', (req, res) => res.json(engines.map(e => e.getExportData())));
app.get('/api/chart-history', async (req, res) => { try { const history = await ChartModel.find().sort({ timestamp: -1 }).limit(500); res.json(history.reverse()); } catch (err) { res.json([]); }});
app.get('/api/toggle/:id', async (req, res) => { const e = engines.find(x => x.id === parseInt(req.params.id)); if(e) { e.liveTradingEnabled = !e.liveTradingEnabled; await SettingModel.findOneAndUpdate({ workerId: e.id }, { liveTradingEnabled: e.liveTradingEnabled }, { upsert: true }).catch(() => {}); } res.json({status: 'ok'}); });
app.get('/api/close-all', async (req, res) => { engines.forEach(e => e.forceClosePosition().catch(err => console.error(err))); res.json({status: 'ok'}); });

// NOTE: HTML is EXACTLY the same except for the lastTradeCount fix inside fetchMetrics()
app.get('/', (req, res) => { res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Material Bot Terminal</title>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root { --bg: #f4f6f8; --panel: #ffffff; --text-primary: #202124; --text-secondary: #5f6368; --green: #0f9d58; --red: #d23f31; --blue: #1a73e8; --yellow: #f4b400; --purple: #8e24aa; --border: #dadce0; --shadow: 0 1px 2px 0 rgba(60,64,67,0.3), 0 1px 3px 1px rgba(60,64,67,0.15); }
        body { font-family: 'Inter', sans-serif; background-color: var(--bg); color: var(--text-primary); margin: 0; padding: 24px; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border); padding-bottom: 16px; margin-bottom: 24px; }
        .header h1 { margin: 0; color: var(--text-primary); font-weight: 800; font-size: 24px; letter-spacing: -0.5px;}
        select { background: #fff; color: var(--text-primary); border: 1px solid var(--border); padding: 8px 12px; border-radius: 6px; font-weight: 600; font-family: 'Inter'; font-size: 14px; cursor: pointer; outline: none;}
        .status-badge { padding: 6px 14px; border-radius: 20px; font-weight: 700; font-size: 11px; color: var(--text-secondary); background: #e8eaed; font-family: 'Inter', sans-serif; text-transform: uppercase; }
        .active-trade { background: var(--blue); color: #fff; box-shadow: 0 2px 6px rgba(26,115,232,0.4); }
        .paper-trade { background: var(--purple); color: #fff; box-shadow: 0 2px 6px rgba(142,36,170,0.4); }
        .cooldown-trade { background: var(--yellow); color: #000; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px; }
        .panel { background: var(--panel); border-radius: 12px; padding: 24px; position: relative; box-shadow: var(--shadow); border: none; }
        .panel h3 { margin: 0 0 20px 0; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: var(--text-secondary); }
        .value { font-family: 'JetBrains Mono', monospace; font-size: 32px; font-weight: 700; color: var(--text-primary); margin-bottom: 4px; }
        .sub-value { font-size: 13px; font-weight: 500; color: var(--text-secondary); margin-bottom: 20px; }
        .green { color: var(--green) !important; } .red { color: var(--red) !important; } .blue { color: var(--blue) !important; } .yellow { color: var(--yellow) !important; } .purple { color: var(--purple) !important; }
        .flex-row { display: flex; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid #f1f3f4; padding-bottom: 8px; align-items: center;}
        .flex-row:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0;}
        .label { font-size: 13px; color: var(--text-secondary); font-weight: 500;}
        .data-point { font-family: 'JetBrains Mono', monospace; font-size: 14px; color: var(--text-primary); font-weight: 700; }
        .chart-container { width: 100%; height: 350px; margin-top: 10px; position: relative;}
        .trade-table { width: 100%; border-collapse: collapse; margin-top: 10px; text-align: left; }
        .trade-table th { padding: 12px; font-size: 12px; color: var(--text-secondary); border-bottom: 1px solid var(--border); }
        .trade-table td { padding: 12px; font-size: 13px; font-weight: 600; font-family: 'JetBrains Mono', monospace; border-bottom: 1px solid #f1f3f4; }
    </style>
</head>
<body>
    <div class="header">
        <div>
            <h1>Instant Trend Follower &nbsp;<select id="instanceSelect"></select>&nbsp;<button id="liveToggleBtn" style="padding: 6px 12px; border-radius: 6px; font-weight: 700; font-family: 'Inter'; font-size: 14px; cursor: pointer; border: none; background: #8e24aa; color: #fff;">PAPER TRADING</button>&nbsp;<button id="closeAllBtn" style="padding: 6px 12px; border-radius: 6px; font-weight: 700; font-family: 'Inter'; font-size: 14px; cursor: pointer; border: none; background: #d23f31; color: #fff;">CLOSE ALL</button></h1>
            <div style="font-size: 13px; font-weight: 500; color: var(--text-secondary); margin-top: 6px;">
                Uptime: <span id="uptime" style="color: var(--text-primary); font-weight:700;">0s</span> 
                &nbsp;|&nbsp; Global PNL: <span id="globalPnl" style="font-weight:700;">$0.0000</span>
                &nbsp;|&nbsp; Global Closed ROI: <span id="globalRoi" style="font-weight:700;">0.00%</span>
                &nbsp;|&nbsp; Global W/L: <span id="globalWL" style="font-weight:700; color: var(--text-primary);">0 / 0</span>
            </div>
        </div>
        <div><div id="statusBadge" class="status-badge">INITIALIZING...</div></div>
    </div>

    <div class="grid">
        <div class="panel" style="border-top: 4px solid var(--yellow);">
            <h3>Trend Detection</h3>
            <div class="flex-row"><span class="label">BINANCE TREND</span><span class="data-point" id="binanceTrend" style="font-size: 16px;">LOAD</span></div>
            <div class="flex-row"><span class="label">ZigZag Threshold</span><span class="data-point" id="noiseFilter">0.25%</span></div>
        </div>

        <div class="panel" style="border-top: 4px solid var(--green);">
            <h3>Net Profit & Strategy State</h3>
            <div class="value" id="netPnl">$0.0000</div>
            <div class="sub-value">Total Est. Fees Paid: <span id="totalFees" class="data-point" style="font-size:13px;">$0.0000</span></div>
            <div class="flex-row"><span class="label">Worker Total ROI</span><span class="data-point" id="workerTotalRoi">0.00%</span></div>
            <div class="flex-row"><span class="label">Trading Mode</span><span class="data-point green" id="strategyMode">TREND FOLLOWER</span></div>
            <div class="flex-row"><span class="label">Current Trade ROI (Net)</span><span class="data-point" id="activeRoi">N/A</span></div>
        </div>

        <div class="panel" style="border-top: 4px solid var(--blue);">
            <h3>Performance Analytics</h3>
            <div class="flex-row" style="margin-top:10px;"><span class="label">Win Rate</span><span class="data-point blue" id="winRate" style="font-size: 20px;">0.00%</span></div>
            <div class="flex-row" style="border-bottom: none;"><span class="label">Total W/L</span><span class="data-point" id="wlRatio">0 / 0</span></div>
        </div>
    </div>

    <div class="grid" style="margin-top: 20px;">
        <div class="panel" style="grid-column: 1 / -1;">
            <h3>Market Structure Overlay (ZigZag Tracking)</h3>
            <div class="chart-container"><canvas id="spreadChart"></canvas></div>
        </div>
    </div>

    <div class="grid" style="margin-top: 20px;">
        <div class="panel" style="border-top: 4px solid var(--purple);">
            <h3>ZigZag Structure (Last 10 + Current)</h3>
            <div style="overflow-x: auto;">
                <table class="trade-table" id="zigZagTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>TYPE</th>
                            <th>PRICE (USDT)</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody id="zigZagBody">
                        <tr><td colspan="4" style="text-align:center; color: #5f6368;">Awaiting data...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="panel" style="border-top: 4px solid var(--border);">
            <h3>Recent Closed Trades</h3>
            <div style="overflow-x: auto;">
                <table class="trade-table" id="tradeHistoryTable">
                    <thead>
                        <tr>
                            <th>TIME</th>
                            <th>SIDE</th>
                            <th>ENTRY</th>
                            <th>EXIT</th>
                            <th>NET ROI</th>
                            <th>NET PNL</th>
                        </tr>
                    </thead>
                    <tbody id="tradeHistoryBody">
                        <tr><td colspan="6" style="text-align:center; color: #5f6368;">No trades yet</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<script>
        const THRESHOLD_SHIFT_TICKS = 30; 

        let selectedInstance = 0; let populatedSelect = false; let lastTradeCount = -1; let lastInstanceData = -1;
        document.getElementById('instanceSelect').addEventListener('change', (e) => { selectedInstance = parseInt(e.target.value); });
        document.getElementById('liveToggleBtn').addEventListener('click', async () => { await fetch('/api/toggle/' + selectedInstance); });
        document.getElementById('closeAllBtn').addEventListener('click', async () => { if(confirm('Force close all active positions across ALL workers?')) await fetch('/api/close-all'); });
        
        const overlayPlugin = {
            id: 'overlayPlugin',
            afterDraw: (chart) => {
                const ctx = chart.ctx;
                if(window._chartTrendText) {
                    ctx.save(); ctx.font = 'bolder 20px Inter'; ctx.fillStyle = window._chartTrendColor || '#5f6368';
                    ctx.textAlign = 'left'; ctx.textBaseline = 'top'; ctx.fillText('BINANCE TREND: ' + window._chartTrendText, 20, 20); ctx.restore();
                }
            }
        };

        const ctx = document.getElementById('spreadChart').getContext('2d');
        const spreadChart = new Chart(ctx, {
            type: 'line',
            data: { labels: [], datasets: [
                { label: 'Binance Raw', data: [], borderColor: 'rgba(244, 180, 0, 0.3)', borderWidth: 1.5, pointRadius: 0, tension: 0.5, cubicInterpolationMode: 'monotone' },
                { label: 'HTX Lag Exchange', data: [], borderColor: '#1a73e8', borderWidth: 2.0, pointRadius: 0, tension: 0.5, cubicInterpolationMode: 'monotone' },
                { label: 'ZigZag Structure', data: [], borderColor: '#8e24aa', borderWidth: 3.5, pointRadius: 3, pointBackgroundColor: '#8e24aa', tension: 0, spanGaps: true },
                { label: 'Trend Threshold', data: [], borderColor: '#f4b400', borderWidth: 2.0, pointRadius: 0, tension: 0.5, cubicInterpolationMode: 'monotone' }
            ]},
            plugins: [overlayPlugin],
            options: { 
                responsive: true, maintainAspectRatio: false, animation: false, normalized: true, 
                scales: { y: { grid: { color: '#e8eaed' }, ticks: { color: '#5f6368', font: { family: 'Inter', size: 11 }, callback: v => v.toFixed(5) } }, x: { display: false } }, 
                plugins: { legend: { position: 'bottom', labels: { color: '#202124', font: { family: 'Inter', weight: 'bold', size: 12 } } }, tooltip: { callbacks: { label: c => c.dataset.label + ': ' + c.parsed.y.toFixed(5) } } } 
            }
        });
        
        let lastChartBMid = 0; let lastChartHMid = 0; const maxPoints = 500; 
        let zigZagTrend = 0; let currentExtremaVal = null; let currentExtremaIdx = -1;
        let smoothedUIThreshold = null; 

        let zigZagHistory = [];
        let zigZagCounter = 1;

        function renderZigZagTable() {
            const tbody = document.getElementById('zigZagBody');
            if(!tbody) return;
            tbody.innerHTML = '';
            
            zigZagHistory.forEach((zz) => {
                const tr = document.createElement('tr');
                tr.innerHTML = \`
                    <td style="color: var(--text-secondary);">#\${zz.id}</td>
                    <td class="\${zz.type === 'HIGH' ? 'green' : 'red'}">\${zz.type}</td>
                    <td>\${zz.price.toFixed(5)}</td>
                    <td style="color: #5f6368; font-size: 11px;">🔒 LOCKED</td>
                \`;
                tbody.appendChild(tr);
            });

            if (window._backendExtrema !== null && window._backendExtrema !== undefined) {
                const currentType = (window._backendTargetSide === 'long' || window._backendZigZag === 1) ? 'UP (TRACKING HIGH)' : 'DOWN (TRACKING LOW)';
                const colorClass = (window._backendTargetSide === 'long' || window._backendZigZag === 1) ? 'green' : 'red';
                const tr = document.createElement('tr');
                tr.style.backgroundColor = 'rgba(26, 115, 232, 0.04)'; 
                tr.innerHTML = \`
                    <td style="color: var(--blue); font-weight: bold;">-</td>
                    <td class="\${colorClass}" style="font-weight: bold;">\${currentType}</td>
                    <td style="font-weight: bold; color: var(--blue);">\${window._backendExtrema.toFixed(5)}</td>
                    <td style="color: var(--blue); font-size: 11px; font-weight: bold;">⏱️ ACTIVE</td>
                \`;
                tbody.appendChild(tr);
            }
        }

        function recordZigZag(price, type) {
            zigZagHistory.push({ id: zigZagCounter++, price: price, type: type });
            if (zigZagHistory.length > 10) zigZagHistory.shift(); 
        }

        function processChartTick(bMid, hMid, ZIGZAG_DECIMAL) {
            if(bMid === lastChartBMid && hMid === lastChartHMid) return;
            lastChartBMid = bMid; lastChartHMid = hMid;
            
            const zzData = spreadChart.data.datasets[2].data; const len = zzData.length;
            
            if (len > 0 && (len - 1) !== currentExtremaIdx && zzData[len - 1] !== undefined) zzData[len - 1] = null;

            spreadChart.data.labels.push(''); 
            spreadChart.data.datasets[0].data.push(bMid); 
            spreadChart.data.datasets[1].data.push(hMid); 
            spreadChart.data.datasets[2].data.push(bMid); 
            const newIdx = spreadChart.data.datasets[2].data.length - 1;

            if (zigZagTrend === 0) { 
                currentExtremaVal = bMid; currentExtremaIdx = newIdx; zigZagTrend = 1; 
            } 
            else {
                let UIlastLockedHigh = null;
                let UIlastLockedLow = null;
                for (let i = zigZagHistory.length - 1; i >= 0; i--) {
                    if (UIlastLockedHigh === null && zigZagHistory[i].type === 'HIGH') UIlastLockedHigh = zigZagHistory[i].price;
                    if (UIlastLockedLow === null && zigZagHistory[i].type === 'LOW') UIlastLockedLow = zigZagHistory[i].price;
                }

                const changeFromExtrema = (bMid - currentExtremaVal) / currentExtremaVal;
                
                if (zigZagTrend === -1 && UIlastLockedHigh !== null && bMid > UIlastLockedHigh) {
                    recordZigZag(currentExtremaVal, 'LOW');
                    zigZagTrend = 1; currentExtremaVal = bMid; currentExtremaIdx = newIdx; 
                    spreadChart.data.datasets[2].data[newIdx] = bMid;
                } 
                else if (zigZagTrend === 1 && UIlastLockedLow !== null && bMid < UIlastLockedLow) {
                    recordZigZag(currentExtremaVal, 'HIGH');
                    zigZagTrend = -1; currentExtremaVal = bMid; currentExtremaIdx = newIdx; 
                    spreadChart.data.datasets[2].data[newIdx] = bMid;
                }
                else if (zigZagTrend === 1) { 
                    if (bMid >= currentExtremaVal) { 
                        spreadChart.data.datasets[2].data[currentExtremaIdx] = null; 
                        currentExtremaVal = bMid; currentExtremaIdx = newIdx; 
                        spreadChart.data.datasets[2].data[newIdx] = bMid; 
                    } 
                    else if (changeFromExtrema <= -ZIGZAG_DECIMAL) { 
                        recordZigZag(currentExtremaVal, 'HIGH');
                        zigZagTrend = -1; currentExtremaVal = bMid; currentExtremaIdx = newIdx; 
                        spreadChart.data.datasets[2].data[newIdx] = bMid; 
                    }
                } else if (zigZagTrend === -1) {
                    if (bMid <= currentExtremaVal) { 
                        spreadChart.data.datasets[2].data[currentExtremaIdx] = null; 
                        currentExtremaVal = bMid; currentExtremaIdx = newIdx; 
                        spreadChart.data.datasets[2].data[newIdx] = bMid; 
                    } 
                    else if (changeFromExtrema >= ZIGZAG_DECIMAL) { 
                        recordZigZag(currentExtremaVal, 'LOW');
                        zigZagTrend = 1; currentExtremaVal = bMid; currentExtremaIdx = newIdx; 
                        spreadChart.data.datasets[2].data[newIdx] = bMid; 
                    }
                }
            }

            const trueExtrema = window._backendExtrema !== undefined && window._backendExtrema !== null ? window._backendExtrema : currentExtremaVal;
            const trueTrend = window._backendZigZag !== undefined && window._backendZigZag !== null ? window._backendZigZag : zigZagTrend;

            let threshold = null;
            if (trueExtrema !== null) {
                if (trueTrend === 1) threshold = trueExtrema * (1 - ZIGZAG_DECIMAL);
                else if (trueTrend === -1) threshold = trueExtrema * (1 + ZIGZAG_DECIMAL);
            }
            
            if (threshold !== null) {
                if (smoothedUIThreshold === null) {
                    smoothedUIThreshold = threshold;
                } else {
                    const diff = threshold - smoothedUIThreshold;
                    if (Math.abs(diff) > 0.002 || Math.abs(diff) > (threshold * 0.001)) {
                        smoothedUIThreshold = threshold;
                    }
                }
                threshold = smoothedUIThreshold;
            }

            spreadChart.data.datasets[3].data.push(threshold);
            
            if (THRESHOLD_SHIFT_TICKS > 0 && spreadChart.data.datasets[3].data.length > THRESHOLD_SHIFT_TICKS) {
                const targetIdx = spreadChart.data.datasets[3].data.length - 1 - THRESHOLD_SHIFT_TICKS;
                spreadChart.data.datasets[3].data[targetIdx] = threshold;
                
                for (let i = targetIdx + 1; i < spreadChart.data.datasets[3].data.length; i++) {
                    spreadChart.data.datasets[3].data[i] = threshold;
                }
            }

            if(spreadChart.data.datasets[0].data.length > maxPoints) {
                spreadChart.data.labels.shift(); 
                spreadChart.data.datasets[0].data.shift(); 
                spreadChart.data.datasets[1].data.shift(); 
                spreadChart.data.datasets[2].data.shift(); 
                spreadChart.data.datasets[3].data.shift(); 
                
                currentExtremaIdx--; 
                if (currentExtremaIdx < 0) { currentExtremaIdx = 0; spreadChart.data.datasets[2].data[0] = currentExtremaVal; }
            }

            renderZigZagTable();
        }

        function updateChartBounds() {
            const ds0 = spreadChart.data.datasets[0].data; const ds1 = spreadChart.data.datasets[1].data; const ds3 = spreadChart.data.datasets[3].data;
            if(ds0.length > 0) {
                let min = Infinity, max = -Infinity;
                for(let i=0; i<ds0.length; i++) { 
                    if(ds0[i] > 0 && ds0[i] < min) min = ds0[i]; 
                    if(ds0[i] > max) max = ds0[i]; 
                    if(ds1[i] > 0 && ds1[i] < min) min = ds1[i]; 
                    if(ds1[i] > max) max = ds1[i]; 
                    if(ds3[i] > 0 && ds3[i] < min) min = ds3[i]; 
                    if(ds3[i] > max) max = ds3[i]; 
                }
                if(min !== Infinity && max !== -Infinity) { spreadChart.options.scales.y.min = min - (min * 0.0005); spreadChart.options.scales.y.max = max + (max * 0.0005); }
            }
        }

        async function initApp() {
            const confRes = await fetch('/api/data');
            const allData = await confRes.json();
            if(allData.length > 0) {
                const ZIGZAG_DECIMAL = allData[0].config.zigZagThresholdPct / 100;
                try {
                    const histRes = await fetch('/api/chart-history');
                    const history = await histRes.json();
                    history.forEach(pt => processChartTick(pt.binanceMid, pt.htxMid, ZIGZAG_DECIMAL));
                    updateChartBounds();
                    spreadChart.update();
                } catch(e) { console.error("History DB load error", e); }
            }
            setInterval(fetchMetrics, 350); 
            fetchMetrics();
        }

        async function fetchMetrics() {
            try {
                const res = await fetch('/api/data'); const allData = await res.json(); 
                if (!populatedSelect && allData.length > 0) {
                    const sel = document.getElementById('instanceSelect');
                    allData.forEach((d, i) => { const opt = document.createElement('option'); opt.value = i; opt.innerText = d.name; sel.appendChild(opt); });
                    populatedSelect = true;
                }

                let gPnl = 0; let gRoi = 0; let gWins = 0; let gLosses = 0;
                allData.forEach(d => { 
                    gPnl += d.metrics.totalNetPnl; 
                    gRoi += d.metrics.totalRoiPct; 
                    gWins += d.metrics.wins;
                    gLosses += d.metrics.losses;
                });
                
                document.getElementById('globalPnl').innerText = '$' + gPnl.toFixed(4); document.getElementById('globalPnl').className = gPnl > 0 ? 'green' : (gPnl < 0 ? 'red' : '');
                document.getElementById('globalRoi').innerText = (gRoi > 0 ? '+' : '') + gRoi.toFixed(2) + '%'; document.getElementById('globalRoi').className = gRoi > 0 ? 'green' : (gRoi < 0 ? 'red' : '');
                document.getElementById('globalWL').innerText = gWins + ' / ' + gLosses;
                
                const data = allData[selectedInstance]; if (!data) return;

                window._backendExtrema = data.leadLagStats.currentExtremaVal;
                window._backendTargetSide = data.leadLagStats.targetSide;
                window._backendZigZag = data.leadLagStats.zigZagTrend;

                document.getElementById('uptime').innerText = data.botInfo.uptime + 's';
                const pnlEl = document.getElementById('netPnl'); pnlEl.innerText = '$' + data.metrics.totalNetPnl.toFixed(4); pnlEl.className = 'value ' + (data.metrics.totalNetPnl > 0 ? 'green' : (data.metrics.totalNetPnl < 0 ? 'red' : ''));
                document.getElementById('totalFees').innerText = '$' + data.metrics.totalFees.toFixed(4);
                
                const wRoi = data.metrics.totalRoiPct || 0;
                const workerRoiEl = document.getElementById('workerTotalRoi');
                workerRoiEl.innerText = (wRoi > 0 ? '+' : '') + wRoi.toFixed(2) + '%';
                workerRoiEl.className = 'data-point ' + (wRoi > 0 ? 'green' : (wRoi < 0 ? 'red' : ''));

                document.getElementById('winRate').innerText = (data.metrics.winRate * 100).toFixed(2) + '%';
                
                document.getElementById('wlRatio').innerText = data.metrics.wins + ' / ' + data.metrics.losses;

                let trText = 'WAITING';
                let trColor = '#f4b400';
                let trClass = 'yellow';

                if (window._backendTargetSide === 'long' || window._backendZigZag === 1) {
                    trText = 'UP (TRACKING HIGH)';
                    trColor = '#0f9d58';
                    trClass = 'green';
                } else if (window._backendTargetSide === 'short' || window._backendZigZag === -1) {
                    trText = 'DOWN (TRACKING LOW)';
                    trColor = '#d23f31';
                    trClass = 'red';
                }

                document.getElementById('binanceTrend').innerText = trText + (trClass === 'green' ? ' 🟢' : (trClass === 'red' ? ' 🔴' : ' ➖'));
                document.getElementById('binanceTrend').className = 'data-point ' + trClass;
                window._chartTrendText = trText;
                window._chartTrendColor = trColor;

                document.getElementById('noiseFilter').innerText = data.config.zigZagThresholdPct + "%";

                const badge = document.getElementById('statusBadge'); const roiEl = document.getElementById('activeRoi'); const btn = document.getElementById('liveToggleBtn');
                
                if (data.botInfo.liveTradingEnabled) { btn.innerText = 'LIVE TRADING (ON)'; btn.style.background = '#0f9d58'; } else { btn.innerText = 'PAPER TRADING'; btn.style.background = '#8e24aa'; }
                
                const now = Date.now();
                if (data.activePositions.length > 0) {
                    const pos = data.activePositions[0];
                    const prefix = pos.isPaper ? '📝 PAPER' : 'IN POS';
                    badge.innerText = prefix + ' [' + pos.side.toUpperCase() + ']'; 
                    badge.className = 'status-badge ' + (pos.isPaper ? 'paper-trade' : 'active-trade'); 
                    roiEl.innerText = pos.exchangeROI.toFixed(2) + '%'; roiEl.className = 'data-point ' + (pos.exchangeROI >= 0 ? 'green' : 'red');
                } else if (data.botInfo.cooldownUntil > now) {
                    const secs = Math.ceil((data.botInfo.cooldownUntil - now) / 1000);
                    badge.innerText = 'COOLDOWN (' + secs + 's)'; badge.className = 'status-badge cooldown-trade'; roiEl.innerText = 'N/A'; roiEl.className = 'data-point';
                } else if (!data.botInfo.liveTradingEnabled) {
                    badge.innerText = 'PAPER AWAITING'; badge.className = 'status-badge paper-trade'; roiEl.innerText = 'N/A'; roiEl.className = 'data-point';
                } else { badge.innerText = 'AWAITING TREND'; badge.className = 'status-badge'; roiEl.innerText = 'N/A'; roiEl.className = 'data-point'; }

                // ⚡ FIXED: Using totalTradesCount so the UI does not freeze at 1000
                const tbody = document.getElementById('tradeHistoryBody');
                if (data.metrics.trades && data.metrics.trades.length > 0) {
                    if (lastTradeCount !== data.metrics.totalTradesCount || lastInstanceData !== selectedInstance) {
                        lastTradeCount = data.metrics.totalTradesCount; lastInstanceData = selectedInstance;
                        tbody.innerHTML = '';
                        const recentTrades = [...data.metrics.trades].reverse().slice(0, 15);
                        recentTrades.forEach(t => {
                            const tr = document.createElement('tr');
                            const d = new Date(t.timestamp);
                            const timeStr = d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0') + ':' + d.getSeconds().toString().padStart(2, '0');
                            const sideColor = t.side === 'long' ? 'green' : 'red';
                            const pnlColor = t.netPnl >= 0 ? 'green' : 'red';
                            
                            tr.innerHTML = \`
                                <td style="color: var(--text-secondary);">\${timeStr}</td>
                                <td class="\${sideColor}">\${(t.side || 'UNK').toUpperCase()}</td>
                                <td>\${(t.entryPrice || 0).toFixed(4)}</td>
                                <td>\${(t.exitPrice || 0).toFixed(4)}</td>
                                <td class="\${pnlColor}">\${(t.roiPct || 0) > 0 ? '+' : ''}\${(t.roiPct || 0).toFixed(2)}%</td>
                                <td class="\${pnlColor}">\${(t.netPnl || 0) > 0 ? '+' : ''}$\${(t.netPnl || 0).toFixed(4)}</td>
                            \`;
                            tbody.appendChild(tr);
                        });
                    }
                } else {
                    if (lastTradeCount !== 0 || lastInstanceData !== selectedInstance) {
                        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color: #5f6368;">No trades yet</td></tr>';
                        lastTradeCount = 0; lastInstanceData = selectedInstance;
                    }
                }

                const bMid = data.marketData.binance.mid; const hMid = data.marketData.htx.mid; 
                if(bMid > 0 && hMid > 0) {
                    processChartTick(bMid, hMid, data.config.zigZagThresholdPct / 100);
                    updateChartBounds();
                    spreadChart.update();
                }
            } catch (e) {}
        }
        
        initApp();

    </script>
</body>
</html>`);});

app.listen(CUSTOM_PORT, '0.0.0.0', async () => {
    console.log(`\n🚀 INSTANT TREND FOLLOWER SERVER RUNNING ON PORT ${CUSTOM_PORT}\n`);
    for (let i = 0; i < engines.length; i++) {
        await engines[i].loadDbSettings(); 
        await engines[i].initialize();
    }
    startMasterStreams();
});
