const fs = require('fs');
const ccxt = require('ccxt');
const express = require('express');
const mongoose = require('mongoose');
const https = require('https');
const crypto = require('crypto');

const keepAliveAgent = new https.Agent({ keepAlive: true, maxSockets: 100, keepAliveMsecs: 30000 });

// ==================== MONGODB SETUP ====================
const MONGO_URI = process.env.MONGO_URI || "mongodb+srv://web88888888888888_db_user:ZETrZHXzaxoekjkm@clusterweb8888.l0rv6hv.mongodb.net/botdb?appName=Clusterweb8888";

mongoose.connect(MONGO_URI)
    .then(() => console.log('✅ MongoDB Connected Successfully'))
    .catch(err => console.error('🚨 MongoDB Connection Error:', err));

// Database Schemas
const UserModel = mongoose.model('User_V2', new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, unique: true, required: true },
    passwordHash: { type: String, required: true },
    salt: { type: String, required: true },
    token: { type: String },
    apiKey: { type: String, default: "" },
    apiSecret: { type: String, default: "" },
    liveTradingEnabled: { type: Boolean, default: false },
    hasActiveSubscription: { type: Boolean, default: false }, 
    paymentTxid: { type: String, default: "" },             
    config: { type: Object, default: {} } 
}));

const TradeModel = mongoose.model('TradeLog_V2', new mongoose.Schema({
    userId: { type: String, required: true }, side: String, entryPrice: Number, exitPrice: Number,
    contracts: Number, marginUsed: Number, grossPnl: Number, grossRoiPct: Number, roiPct: Number, 
    netPnl: Number, feeCost: Number, timestamp: { type: Date, default: Date.now }, exitReason: String
}));

const ChartDataModel = mongoose.model('ChartData_V2', new mongoose.Schema({
    htxMid: Number, timestamp: { type: Date, default: Date.now, expires: 86400 } 
}));

const AnalyticsModel = mongoose.model('SiteAnalytics_V2', new mongoose.Schema({
    key: { type: String, default: "global" },
    views: { type: Number, default: 0 },
    uniques: { type: Number, default: 0 },
    knownIds: { type: [String], default: [] }
}));

// ==================== BASE CONFIGURATION ====================
const CUSTOM_PORT = process.env.PORT || 3000;

const BASE_CONFIG = {
    htxSymbol: 'SHIB/USDT:USDT', leverage: 75, baseContracts: 1, maxContracts: 0, 
    contractSize: 1000, marginMode: 'cross', fees: { taker: 0.0004 }, 
    takeProfitPct: 10.0, stopLossPct: -600.0, dcaEnabled: true, dcaSpreadPct: 1.0, dcaMultiplier: 2.0, dcaMaxSteps: 10, chartTicks: 800
};

const globalMarketData = { htx: { bid: 0, ask: 0, mid: 0, timestamp: 0 } };
const memoryChartHistory = []; 
const publicHtx = new ccxt.pro.htx({ options: { defaultType: 'swap', defaultSubType: 'linear' } });

// ==================== SECURITY & AUTH ====================
function hashPassword(password, salt) { return crypto.scryptSync(password, salt, 64).toString('hex'); }
function generateToken() { return crypto.randomBytes(32).toString('hex'); }

async function authMiddleware(req, res, next) {
    const token = req.headers['authorization'];
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    const user = await UserModel.findOne({ token });
    if (!user) return res.status(401).json({ error: 'Unauthorized' });
    req.user = user;
    next();
}

// ==================== METRICS ENGINE ====================
class PerformanceMetrics {
    constructor(userId) {
        this.userId = userId; this.trades = []; 
        this.totalGrossPnl = 0; this.totalNetPnl = 0; this.totalFees = 0; this.totalRoiPct = 0;
        this.wins = 0; this.losses = 0; this.winRate = 0; this.totalTradesCount = 0; this.maxMarginUsed = 0; 
    }
    async init() { 
        const dbTrades = await TradeModel.find({ userId: this.userId }).sort({ timestamp: 1 }).lean(); 
        dbTrades.forEach(t => this.processTrade(t, false)); 
    }
    recordTrade(trade) { this.processTrade(trade, true); }
    processTrade(trade, saveToDb = true) {
        this.totalTradesCount++; if (!trade.timestamp) trade.timestamp = Date.now();
        this.trades.push(trade); if (this.trades.length > 2000) this.trades.shift(); 
        const margin = trade.marginUsed || 0; if (margin > this.maxMarginUsed) this.maxMarginUsed = margin;
        this.totalNetPnl += trade.netPnl || 0; this.totalFees += trade.feeCost || 0; this.totalRoiPct += trade.roiPct || 0; 
        if (trade.netPnl > 0) this.wins++; else this.losses++;
        this.winRate = this.trades.length ? ((this.wins / this.trades.length) * 100).toFixed(2) : 0;
        if (saveToDb) TradeModel.create({ ...trade, userId: this.userId }).catch(()=>{});
    }
    updateMaxMargin(margin) { if (margin > this.maxMarginUsed) this.maxMarginUsed = margin; }
}

// ==================== USER BOT INSTANCE ====================
class UserTradeInstance {
    constructor(user) {
        this.userId = user._id.toString(); 
        this.config = { ...BASE_CONFIG, ...(user.config || {}) }; 
        this.startTime = Date.now(); this.metrics = new PerformanceMetrics(this.userId);
        
        // Strictly memory-bound array. Never saved to DB.
        this.activePositions = []; 
        
        this.isTrading = false; this.lastCloseTime = 0;
        this.applyUserKeys(user);
    }

    applyUserKeys(user) {
        this.liveTradingEnabled = user.liveTradingEnabled && user.hasActiveSubscription;
        const key = user.apiKey || "demo"; const secret = user.apiSecret || "demo";
        this.htx = new ccxt.pro.htx({ apiKey: key, secret: secret, agent: keepAliveAgent, enableRateLimit: false, options: { defaultType: 'swap', defaultSubType: 'linear', defaultMarginMode: this.config.marginMode, positionMode: 'hedged' } });
    }
    
    async initialize() {
        await this.metrics.init(); 
        await this.connectExchange();
        this.startExchangeROISync();
    }

    async connectExchange() {
        try {
            if(this.liveTradingEnabled) {
                await this.htx.loadMarkets(); 
                const positions = await this.htx.fetchPositions([this.config.htxSymbol]); 
                const openPos = positions.find(p => p.contracts > 0);
                
                this.activePositions = []; 

                if (openPos) {
                    const sizeUsd = openPos.contracts * this.config.contractSize * openPos.entryPrice;
                    const marginUsed = sizeUsd / this.config.leverage; 
                    this.metrics.updateMaxMargin(marginUsed);
                    this.activePositions.push({ id: Date.now(), side: openPos.side, entryPrice: openPos.entryPrice, contracts: openPos.contracts, size: sizeUsd, marginUsed: marginUsed, exchangeROI: openPos.percentage || 0, entryTime: Date.now(), isPaper: false, maxRoi: 0, dcaStep: 0, lastDcaTime: 0 });
                }
                await this.htx.setLeverage(this.config.leverage, this.config.htxSymbol, { marginMode: this.config.marginMode }).catch(()=>{});
                return { success: true };
            } else {
                this.activePositions = []; 
                return { success: true };
            }
        } catch (error) { 
            console.log(`[Worker ${this.userId}] Initialization Error:`, error.message); 
            this.liveTradingEnabled = false; 
            return { success: false, message: error.message }; 
        }
    }

    async evaluateAIEntry() {
        if (this.isTrading || this.activePositions.length > 0 || (Date.now() - this.lastCloseTime < 3000)) return;
        const signal = Math.random() > 0.5 ? 'long' : 'short';
        await this.syncState(signal);
    }

    async checkExits() {
        if (this.isTrading || this.activePositions.length === 0) return;
        const pos = this.activePositions[0];
        let currentPrice = pos.side === 'long' ? globalMarketData.htx.bid : globalMarketData.htx.ask;
        if (!currentPrice || currentPrice === 0) currentPrice = globalMarketData.htx.mid;
        if (!currentPrice) return;
        
        const grossPnlPercent = pos.side === 'long' ? ((currentPrice - pos.entryPrice) / pos.entryPrice) * 100 : ((pos.entryPrice - currentPrice) / pos.entryPrice) * 100;
        const currentGrossRoi = grossPnlPercent * this.config.leverage;
        
        if (currentGrossRoi >= this.config.takeProfitPct) { await this.forceClosePosition("TAKE_PROFIT"); return; }
        if (currentGrossRoi <= this.config.stopLossPct) { await this.forceClosePosition("STOP_LOSS"); return; }
        
        const priceDropPct = -grossPnlPercent; 
        if (this.config.dcaEnabled && (pos.dcaStep || 0) < this.config.dcaMaxSteps) {
            if (pos.lastDcaTime && (Date.now() - pos.lastDcaTime) < 3000) return;
            if (priceDropPct >= this.config.dcaSpreadPct) { 
                await this.executeDCA(pos, currentPrice); 
                return; 
            }
        }
    }

    async executeDCA(pos, execPrice) {
        try {
            this.isTrading = true; 
            pos.lastDcaTime = Date.now(); 
            const nextStep = (pos.dcaStep || 0) + 1; 
            
            let addContracts = Math.floor(this.config.baseContracts * Math.pow(this.config.dcaMultiplier, nextStep));
            if (addContracts <= 0 || !isFinite(addContracts)) addContracts = this.config.baseContracts; 
            
            const maxDynamicLimit = pos.contracts * 500; 
            if (addContracts > maxDynamicLimit) addContracts = Math.ceil(maxDynamicLimit);

            const addSizeUsd = addContracts * this.config.contractSize * execPrice; 
            const newTotalContracts = pos.contracts + addContracts; 

            if (this.config.maxContracts > 0 && newTotalContracts >= this.config.maxContracts) {
                this.isTrading = false; 
                const oppositeSide = pos.side === 'long' ? 'short' : 'long';
                await this.forceClosePosition("MAX_QTY_REVERSAL");
                setTimeout(() => { this.syncState(oppositeSide).catch(err => console.error("Reversal Error:", err)); }, 1500);
                return;
            }

            const newTotalSizeUsd = pos.size + addSizeUsd;
            const simulatedNewEntry = newTotalSizeUsd / (newTotalContracts * this.config.contractSize); 
            const newMarginUsed = newTotalSizeUsd / this.config.leverage;

            if (!this.liveTradingEnabled || pos.isPaper) {
                pos.contracts = newTotalContracts; pos.size = newTotalSizeUsd; pos.entryPrice = simulatedNewEntry; pos.marginUsed = newMarginUsed; pos.dcaStep = nextStep;
                this.metrics.updateMaxMargin(newMarginUsed);
            } else {
                const orderSide = pos.side === 'long' ? 'buy' : 'sell';
                const openRes = await this.htx.createMarketOrder(this.config.htxSymbol, orderSide, addContracts, undefined, { offset: 'open', marginMode: this.config.marginMode, lever_rate: this.config.leverage });
                if (openRes && openRes.id) { pos.contracts = newTotalContracts; pos.size = newTotalSizeUsd; pos.entryPrice = simulatedNewEntry; pos.marginUsed = newMarginUsed; pos.dcaStep = nextStep; this.metrics.updateMaxMargin(newMarginUsed); }
            }
        } catch (err) { console.error('[DCA Error]', err.message); } finally { this.isTrading = false; }
    }

    async syncState(targetSide) {
        if (this.isTrading || this.activePositions.length > 0) return;
        try {
            this.isTrading = true; const isPaper = !this.liveTradingEnabled; const orderSide = targetSide === 'long' ? 'buy' : 'sell'; const contracts = this.config.baseContracts;
            if (isPaper) {
                let executionPrice = targetSide === 'long' ? globalMarketData.htx.ask : globalMarketData.htx.bid;
                if (!executionPrice || executionPrice === 0) executionPrice = globalMarketData.htx.mid;
                const sizeUsd = contracts * this.config.contractSize * executionPrice;
                const marginUsed = sizeUsd / this.config.leverage;
                this.activePositions = [{ id: Date.now(), side: targetSide, entryPrice: executionPrice, contracts: contracts, size: sizeUsd, marginUsed: marginUsed, entryTime: Date.now(), exchangeROI: 0, isPaper, maxRoi: 0, dcaStep: 0, lastDcaTime: 0 }];
                this.metrics.updateMaxMargin(marginUsed);
            } else {
                const openRes = await this.htx.createMarketOrder(this.config.htxSymbol, orderSide, contracts, undefined, { offset: 'open', marginMode: this.config.marginMode, lever_rate: this.config.leverage });
                if (!openRes || !openRes.id) throw new Error("API did not return an Order ID.");
                await new Promise(r => setTimeout(r, 500)); 
                let realEntryPrice = orderSide === 'buy' ? globalMarketData.htx.ask : globalMarketData.htx.bid;
                if (!realEntryPrice || realEntryPrice === 0) realEntryPrice = globalMarketData.htx.mid;
                try { const oOrder = await this.htx.fetchOrder(openRes.id, this.config.htxSymbol); if (oOrder && oOrder.average) realEntryPrice = oOrder.average; } catch(e){}
                const sizeUsd = contracts * this.config.contractSize * realEntryPrice;
                const marginUsed = sizeUsd / this.config.leverage;
                this.activePositions = [{ id: Date.now(), side: targetSide, entryPrice: realEntryPrice, contracts: contracts, size: sizeUsd, marginUsed: marginUsed, entryTime: Date.now(), exchangeROI: 0, isPaper: false, maxRoi: 0, dcaStep: 0, lastDcaTime: 0 }];
                this.metrics.updateMaxMargin(marginUsed);
            }
        } catch (err) { this.activePositions = []; } finally { this.isTrading = false; }
    }

    async forceClosePosition(reason = "MANUAL") {
        if (this.isTrading || this.activePositions.length === 0) return;
        const snapPos = { ...this.activePositions[0] };
        try {
            this.isTrading = true; const closeSide = snapPos.side === 'long' ? 'sell' : 'buy';
            if (!snapPos.isPaper && this.liveTradingEnabled) {
                const closeRes = await this.htx.createMarketOrder(this.config.htxSymbol, closeSide, snapPos.contracts, undefined, { reduceOnly: true, offset: 'close', marginMode: this.config.marginMode, lever_rate: this.config.leverage });
                this.activePositions = []; await new Promise(r => setTimeout(r, 500));
                let realExitPrice = closeSide === 'sell' ? globalMarketData.htx.bid : globalMarketData.htx.ask;
                if (!realExitPrice || realExitPrice === 0) realExitPrice = globalMarketData.htx.mid;
                if (closeRes && closeRes.id) { try { const cOrder = await this.htx.fetchOrder(closeRes.id, this.config.htxSymbol); if (cOrder && cOrder.average) realExitPrice = cOrder.average; } catch(e){} }
                const margin = snapPos.size / this.config.leverage; 
                const netPnlUsd = ((snapPos.side === 'long' ? ((realExitPrice - snapPos.entryPrice) / snapPos.entryPrice) * 100 : ((snapPos.entryPrice - realExitPrice) / snapPos.entryPrice) * 100) / 100) * snapPos.size - snapPos.size * (this.config.fees.taker * 2);
                this.metrics.recordTrade({ side: snapPos.side, contracts: snapPos.contracts, entryPrice: snapPos.entryPrice, exitPrice: realExitPrice, marginUsed: margin, netPnl: netPnlUsd, roiPct: (netPnlUsd/margin)*100, exitReason: reason });
            } else {
                this.activePositions = []; let currentPrice = snapPos.side === 'long' ? globalMarketData.htx.bid : globalMarketData.htx.ask;
                if (!currentPrice || currentPrice === 0) currentPrice = globalMarketData.htx.mid;
                const margin = snapPos.size / this.config.leverage; 
                const netPnlUsd = ((snapPos.side === 'long' ? ((currentPrice - snapPos.entryPrice) / snapPos.entryPrice) * 100 : ((snapPos.entryPrice - currentPrice) / snapPos.entryPrice) * 100) / 100) * snapPos.size - snapPos.size * (this.config.fees.taker * 2);
                this.metrics.recordTrade({ side: snapPos.side, contracts: snapPos.contracts, entryPrice: snapPos.entryPrice, exitPrice: currentPrice, marginUsed: margin, netPnl: netPnlUsd, roiPct: (netPnlUsd/margin)*100, exitReason: reason });
            }
            this.lastCloseTime = Date.now();
        } catch (error) {} finally { this.isTrading = false; }
    }
    
    startExchangeROISync() {
        setInterval(() => {
            if (this.activePositions.length === 0 || this.isTrading) return;
            const pos = this.activePositions[0];
            if (pos.isPaper || !this.liveTradingEnabled) {
                const markPrice = globalMarketData.htx.mid; 
                if (markPrice && pos.entryPrice) { pos.exchangeROI = ((((pos.side === 'long' ? ((markPrice - pos.entryPrice) / pos.entryPrice) : ((pos.entryPrice - markPrice) / pos.entryPrice)) * 100) / 100) * pos.size - pos.size * (this.config.fees.taker * 2)) / (pos.size / this.config.leverage) * 100; }
            }
        }, 300);
    }

    getExportData() { 
        return { 
            config: this.config, liveTradingEnabled: this.liveTradingEnabled, uptime: Math.floor((Date.now() - this.startTime) / 1000),
            metrics: this.metrics, activePositions: this.activePositions, marketData: { htx: globalMarketData.htx } 
        }; 
    }
}

// ==================== WORKER MANAGER ====================
const activeWorkers = new Map();

async function startMasterStreams() {
    let marketsLoaded = false; while (!marketsLoaded) { try { await publicHtx.loadMarkets(); marketsLoaded = true; } catch (e) { await new Promise(r => setTimeout(r, 5000)); } }
    
    (async function streamHTX() {
        let lastHistorySave = 0;
        while (true) {
            try {
                const ticker = await publicHtx.watchTicker(BASE_CONFIG.htxSymbol); const mid = ((ticker.bid || ticker.last) + (ticker.ask || ticker.last)) / 2;
                globalMarketData.htx = { bid: ticker.bid, ask: ticker.ask, mid: mid, timestamp: Date.now() };
                
                if (Date.now() - lastHistorySave > 2000) { 
                    const doc = { htxMid: mid }; memoryChartHistory.push(doc); 
                    if (memoryChartHistory.length > 5000) memoryChartHistory.shift(); 
                    ChartDataModel.create(doc).catch(()=>{}); lastHistorySave = Date.now(); 
                }

                activeWorkers.forEach(worker => { worker.checkExits().catch(()=>{}); worker.evaluateAIEntry().catch(()=>{}); });
            } catch (e) { await new Promise(r => setTimeout(r, 2000)); }
        }
    })();
}

async function loadAllUsers() {
    const users = await UserModel.find({});
    for(const u of users) {
        const worker = new UserTradeInstance(u);
        await worker.initialize();
        activeWorkers.set(u._id.toString(), worker);
    }
}

// ==================== ANALYTICS ENGINE ====================
const activeSessions = new Map();

setInterval(() => {
    const now = Date.now();
    for (const [sid, data] of activeSessions.entries()) {
        if (now - data.lastSeen > 15000) { 
            activeSessions.delete(sid);
        }
    }
}, 5000);

// ==================== EXPRESS SERVER & API ====================
const app = express(); app.use(express.json());

// Analytics Routes
app.post('/api/analytics/track', async (req, res) => {
    const { sessionId, page, isView } = req.body;
    if (!sessionId) return res.status(400).json({ error: 'Missing session' });

    activeSessions.set(sessionId, { page: page || 'unknown', lastSeen: Date.now() });

    if (isView) {
        try {
            let doc = await AnalyticsModel.findOne({ key: "global" });
            if (!doc) doc = await AnalyticsModel.create({ key: "global" });
            
            doc.views += 1;
            if (!doc.knownIds.includes(sessionId)) {
                doc.knownIds.push(sessionId);
                doc.uniques += 1;
            }
            await doc.save();
        } catch(e) {}
    }
    res.json({ status: 'ok' });
});

app.get('/api/analytics/stats', async (req, res) => {
    try {
        let doc = await AnalyticsModel.findOne({ key: "global" });
        if (!doc) doc = { views: 0, uniques: 0 };
        
        const pageBreakdown = {};
        for (const data of activeSessions.values()) {
            pageBreakdown[data.page] = (pageBreakdown[data.page] || 0) + 1;
        }

        res.json({
            online: activeSessions.size,
            views: doc.views,
            uniques: doc.uniques,
            pages: pageBreakdown
        });
    } catch(e) {
        res.status(500).json({ error: 'Failed to load stats' });
    }
});

// Auth Routes
app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const existing = await UserModel.findOne({ email });
        if(existing) return res.status(400).json({ error: 'Email already exists' });
        
        const salt = crypto.randomBytes(16).toString('hex');
        const passwordHash = hashPassword(password, salt);
        const token = generateToken();

        const user = await UserModel.create({ name, email, passwordHash, salt, token });
        const worker = new UserTradeInstance(user);
        await worker.initialize();
        activeWorkers.set(user._id.toString(), worker);

        res.json({ token, user: { name: user.name, email: user.email } });
    } catch(e) { res.status(500).json({ error: 'Registration failed' }); }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await UserModel.findOne({ email });
        if(!user) return res.status(400).json({ error: 'Invalid credentials' });
        
        const hash = hashPassword(password, user.salt);
        if(hash !== user.passwordHash) return res.status(400).json({ error: 'Invalid credentials' });

        user.token = generateToken();
        await user.save();
        res.json({ token: user.token, user: { name: user.name, email: user.email } });
    } catch(e) { res.status(500).json({ error: 'Login failed' }); }
});

app.get('/api/user/me', authMiddleware, (req, res) => {
    res.json({ 
        name: req.user.name, 
        email: req.user.email, 
        apiKey: req.user.apiKey, 
        liveTradingEnabled: req.user.liveTradingEnabled,
        hasActiveSubscription: req.user.hasActiveSubscription 
    });
});

app.post('/api/user/pay', authMiddleware, async (req, res) => {
    try {
        const { txid } = req.body;
        if (!txid || txid.trim().length < 10) {
            return res.status(400).json({ error: 'Invalid Transaction ID provided.' });
        }
        req.user.hasActiveSubscription = true;
        req.user.paymentTxid = txid.trim();
        await req.user.save();
        
        const worker = activeWorkers.get(req.user._id.toString());
        if (worker) worker.applyUserKeys(req.user);

        res.json({ status: 'ok' });
    } catch(e) { res.status(500).json({ error: 'Failed to process payment verification.' }); }
});

app.post('/api/user/keys', authMiddleware, async (req, res) => {
    try {
        const { apiKey, apiSecret, liveTradingEnabled } = req.body;
        
        if (liveTradingEnabled && !req.user.hasActiveSubscription) {
            return res.status(403).json({ error: 'Live trading requires an active $9.99 subscription.' });
        }

        req.user.apiKey = apiKey; req.user.apiSecret = apiSecret; req.user.liveTradingEnabled = Boolean(liveTradingEnabled); 

        let connectionResult = { success: true };
        let worker = activeWorkers.get(req.user._id.toString());
        if(worker) {
            worker.applyUserKeys(req.user);
            connectionResult = await worker.connectExchange();
            req.user.liveTradingEnabled = worker.liveTradingEnabled;
        }
        await req.user.save();
        
        if (liveTradingEnabled && !connectionResult.success) { return res.json({ error: 'Exchange Error: ' + connectionResult.message }); }
        res.json({ status: 'ok' });
    } catch(e) { res.status(500).json({ error: 'Failed to update settings' }); }
});

app.post('/api/user/config', authMiddleware, async (req, res) => {
    const worker = activeWorkers.get(req.user._id.toString());
    if(!worker) return res.status(400).json({ error: 'Worker not active' });
    
    const { tpPct, slPct, baseContracts, maxContracts, contractSize, dcaEnabled, dcaSpread, dcaMultiplier, dcaSteps } = req.body;
    const parseAndSet = (val, parseFunc, target, key) => { if (val !== undefined && val !== "") { const parsed = parseFunc(val); if (!isNaN(parsed)) target[key] = parsed; } };

    parseAndSet(tpPct, parseFloat, worker.config, 'takeProfitPct');
    parseAndSet(slPct, parseFloat, worker.config, 'stopLossPct');
    parseAndSet(baseContracts, parseInt, worker.config, 'baseContracts');
    parseAndSet(maxContracts, parseInt, worker.config, 'maxContracts');
    parseAndSet(contractSize, parseInt, worker.config, 'contractSize');
    if (dcaEnabled !== undefined) worker.config.dcaEnabled = Boolean(dcaEnabled);
    parseAndSet(dcaSpread, parseFloat, worker.config, 'dcaSpreadPct');
    parseAndSet(dcaMultiplier, parseFloat, worker.config, 'dcaMultiplier');
    parseAndSet(dcaSteps, parseInt, worker.config, 'dcaMaxSteps');

    req.user.config = worker.config;
    req.user.markModified('config');
    await req.user.save();

    res.json({status: 'ok', config: worker.config});
});

app.post('/api/user/reset-metrics', authMiddleware, async (req, res) => {
    try {
        const worker = activeWorkers.get(req.user._id.toString());
        if(worker) {
            await TradeModel.deleteMany({ userId: req.user._id.toString() });
            worker.metrics = new PerformanceMetrics(worker.userId);
        }
        res.json({status: 'ok'});
    } catch(err) { res.status(500).json({error: 'Failed to reset metrics'}); }
});

app.get('/api/data', authMiddleware, (req, res) => {
    const worker = activeWorkers.get(req.user._id.toString());
    if(!worker) return res.status(404).json({ error: "Worker not found" });
    res.json(worker.getExportData());
});

app.get('/api/chart-history', (req, res) => res.json(memoryChartHistory.slice(-800))); 
app.get('/api/close-all', authMiddleware, async (req, res) => { 
    const worker = activeWorkers.get(req.user._id.toString());
    if(worker) await worker.forceClosePosition("MANUAL_FORCE_CLOSE").catch(()=>{}); 
    res.json({status: 'ok'}); 
});

// ==================== FRONTEND UI ====================
app.get('/', (req, res) => { res.send(`<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="description" content="RDCA is a high-frequency, mathematical Dollar-Cost-Averaging bot. Automate your exchange trading via secure API integration.">
    <meta name="keywords" content="trading bot, algorithmic trading, DCA strategy, martingale, crypto auto trader, HTX bot">
    <title>RDCA Expert | Pure Mathematical Trading</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&family=Roboto+Mono:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: 'Roboto', sans-serif; background-color: #fafafa; color: #111827; }
        .font-mono { font-family: 'Roboto Mono', monospace; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 300, 'GRAD' 0, 'opsz' 24; vertical-align: middle; }
        
        .ui-card { background-color: #ffffff; border-radius: 16px; box-shadow: 0 4px 24px -4px rgba(0,0,0,0.04); }
        .ui-card-hover { transition: transform 0.2s, box-shadow 0.2s; }
        .ui-card-hover:hover { transform: translateY(-3px); box-shadow: 0 10px 30px -5px rgba(0,0,0,0.08); }
        
        .input-minimal { width: 100%; border: 1px solid #e5e7eb; border-radius: 8px; padding: 10px 14px; font-size: 14px; outline: none; transition: all 0.2s; background: #fafafa; }
        .input-minimal:focus { border-color: #000000; background: #ffffff; box-shadow: 0 0 0 2px rgba(0,0,0,0.05); }
        
        .btn-primary { background: #000000; color: #ffffff; border-radius: 8px; padding: 10px 20px; font-size: 14px; font-weight: 500; cursor: pointer; transition: background 0.2s; text-align: center; }
        .btn-primary:hover { background: #374151; }
        
        .btn-secondary { background: #ffffff; color: #374151; border: 1px solid #d1d5db; border-radius: 8px; padding: 10px 20px; font-size: 14px; font-weight: 500; cursor: pointer; transition: all 0.2s; text-align: center; }
        .btn-secondary:hover { background: #f9fafb; border-color: #9ca3af; }
        
        .view-section { display: none; animation: fade 0.3s ease; }
        @keyframes fade { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
        .active-view { display: block; }
    </style>
</head>
<body class="antialiased min-h-screen flex flex-col selection:bg-gray-200">

    <header class="bg-white/80 backdrop-blur-md shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
            <div class="flex items-center gap-2 cursor-pointer" onclick="nav('home')">
                <span class="material-symbols-outlined text-2xl font-bold text-black">blur_on</span>
                <span class="font-bold tracking-tight text-lg">RDCA</span>
            </div>
            
            <nav id="nav-public" class="flex items-center gap-4 text-sm font-medium text-gray-500">
                <button onclick="nav('analytics')" class="hover:text-black transition flex items-center gap-1"><span class="material-symbols-outlined text-[16px]">monitoring</span> Stats</button>
                <div class="w-px h-4 bg-gray-200 mx-1"></div>
                <button onclick="nav('login')" class="hover:text-black transition">Login</button>
                <button onclick="nav('register')" class="btn-primary py-1.5 px-4 rounded-md">Get Started</button>
            </nav>
            
            <nav id="nav-private" class="hidden items-center gap-6 text-sm font-medium">
                <span id="nav-user-name" class="text-gray-500 hidden sm:block"></span>
                <button onclick="nav('analytics')" class="text-gray-500 hover:text-black transition flex items-center gap-1"><span class="material-symbols-outlined text-[18px]">monitoring</span></button>
                <button onclick="nav('dashboard')" class="hover:text-black transition">Dashboard</button>
                <button onclick="nav('pricing')" class="text-green-600 font-bold hover:text-green-700 transition flex items-center gap-1"><span class="material-symbols-outlined text-[18px]">workspace_premium</span> Billing</button>
                <button onclick="logout()" class="text-red-500 hover:text-red-700 transition">Logout</button>
            </nav>
        </div>
    </header>

    <main class="flex-grow flex flex-col justify-center">
        
        <!-- EXTENDED HOME VIEW -->
        <section id="view-home" class="view-section active-view w-full">
            
            <!-- Hero -->
            <div class="max-w-5xl mx-auto px-4 pt-24 pb-16 text-center">
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gray-100 text-xs font-bold uppercase tracking-widest text-gray-600 mb-6 border border-gray-200">
                    <span class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> HTX Exchange Supported
                </div>
                <h1 class="text-5xl sm:text-6xl md:text-7xl font-extrabold tracking-tight mb-6 leading-tight">Algorithmic Math.<br><span class="text-gray-400">Zero Emotion.</span></h1>
                <p class="text-lg md:text-xl text-gray-500 mb-10 max-w-2xl mx-auto leading-relaxed">RDCA utilizes a highly aggressive Dollar-Cost-Averaging (Martingale) recovery system to force mathematical profitability across market noise.</p>
                <button onclick="nav('register')" class="btn-primary text-base px-10 py-4 shadow-lg shadow-black/20 flex items-center gap-2 mx-auto">
                    Launch Web Terminal <span class="material-symbols-outlined text-[20px]">arrow_forward</span>
                </button>
            </div>

            <!-- Features Grid -->
            <div class="bg-white border-y border-gray-100 py-20">
                <div class="max-w-6xl mx-auto px-4">
                    <div class="text-center mb-16">
                        <h2 class="text-3xl font-bold mb-3">Engineered for Precision</h2>
                        <p class="text-gray-500">Stop relying on subjective chart patterns. Trade with geometric probabilities.</p>
                    </div>
                    <div class="grid md:grid-cols-3 gap-8 text-left">
                        <div class="ui-card p-8 ui-card-hover border border-gray-50">
                            <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mb-6">
                                <span class="material-symbols-outlined text-2xl text-black">calculate</span>
                            </div>
                            <h3 class="font-bold text-xl mb-3">Martingale Recovery</h3>
                            <p class="text-sm text-gray-500 leading-relaxed">If a trade goes against you, the bot automatically buys larger grid positions based on your chosen Spread and Multiplier to drastically bring your break-even point closer.</p>
                        </div>
                        <div class="ui-card p-8 ui-card-hover border border-gray-50">
                            <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mb-6">
                                <span class="material-symbols-outlined text-2xl text-black">key</span>
                            </div>
                            <h3 class="font-bold text-xl mb-3">Non-Custodial execution</h3>
                            <p class="text-sm text-gray-500 leading-relaxed">We never hold your funds. You connect your HTX API keys strictly for trading permissions. Withdrawals are physically impossible for our engine to execute.</p>
                        </div>
                        <div class="ui-card p-8 ui-card-hover border border-gray-50">
                            <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mb-6">
                                <span class="material-symbols-outlined text-2xl text-black">bolt</span>
                            </div>
                            <h3 class="font-bold text-xl mb-3">High-Frequency Node</h3>
                            <p class="text-sm text-gray-500 leading-relaxed">Hosted on dedicated infrastructure, the bot evaluates market ticks multiple times a second to ensure your Take Profit is executed with absolute minimum latency.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Case Studies Section -->
            <div class="bg-gray-50 py-20">
                <div class="max-w-6xl mx-auto px-4">
                    <div class="text-center mb-16">
                        <h2 class="text-3xl font-bold mb-3">Realistic Trading Scenarios</h2>
                        <p class="text-gray-500">Understanding how the grid mitigates risk in real market environments.</p>
                    </div>
                    
                    <div class="grid md:grid-cols-2 gap-8">
                        <div class="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
                            <div class="flex items-center gap-3 mb-4">
                                <span class="material-symbols-outlined text-red-500 text-3xl">trending_down</span>
                                <h3 class="text-xl font-bold">The Flash Crash Mitigation</h3>
                            </div>
                            <p class="text-sm text-gray-600 mb-4 leading-relaxed">During sudden 10% market drops, normal traders get stopped out or trapped. RDCA's logic activates immediately:</p>
                            <ul class="text-sm text-gray-500 space-y-2 mb-6 font-mono bg-gray-50 p-4 rounded-md">
                                <li>> Entry Long at $1.00 (1 Qty)</li>
                                <li>> Price drops to $0.98. Bot buys 2 Qty.</li>
                                <li>> Price drops to $0.96. Bot buys 4 Qty.</li>
                                <li>> Average Entry pulled heavily down to $0.968.</li>
                            </ul>
                            <p class="text-sm text-gray-600"><strong>Result:</strong> Even though the price crashed significantly, a tiny 1% bounce to $0.978 triggers the Take Profit. The bot exits entirely in the green while the rest of the market is still waiting for recovery.</p>
                        </div>

                        <div class="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
                            <div class="flex items-center gap-3 mb-4">
                                <span class="material-symbols-outlined text-blue-500 text-3xl">swap_horiz</span>
                                <h3 class="text-xl font-bold">Riding the Choppy Market</h3>
                            </div>
                            <p class="text-sm text-gray-600 mb-4 leading-relaxed">When the market moves sideways with no clear trend, breakout strategies suffer heavy losses from "fake-outs."</p>
                            <div class="text-sm text-gray-500 space-y-2 mb-6 font-mono bg-gray-50 p-4 rounded-md border-l-4 border-black">
                                <p>Setup: 5% Take Profit, 1% DCA Spread.</p>
                                <p>Behavior: The bot executes hundreds of micro-trades during choppy consolidation. It scales in slightly on minor dips and instantly takes profit on the opposing wave.</p>
                            </div>
                            <p class="text-sm text-gray-600"><strong>Result:</strong> Steady, passive accumulation of base currency. While trend-traders are chopped up, the grid feasts on the localized volatility.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Testimonials -->
            <div class="py-20 bg-white border-b border-gray-100">
                <div class="max-w-6xl mx-auto px-4 text-center">
                    <h2 class="text-3xl font-bold mb-12">What Our Users Are Experiencing</h2>
                    <div class="grid md:grid-cols-3 gap-6 text-left">
                        <div class="p-6 bg-gray-50 rounded-xl">
                            <div class="flex text-yellow-400 mb-3"><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span></div>
                            <p class="text-sm text-gray-600 italic mb-4">"It completely replaced my emotional trading. I set my API keys, turned the DCA multiplier to 1.5, and just let it run on autopilot."</p>
                            <p class="font-bold text-sm text-gray-800">— Michael R.</p>
                        </div>
                        <div class="p-6 bg-gray-50 rounded-xl">
                            <div class="flex text-yellow-400 mb-3"><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span></div>
                            <p class="text-sm text-gray-600 italic mb-4">"The setup is straightforward if you know what a DCA grid is. The dashboard is minimalist but the backend execution speed is phenomenal."</p>
                            <p class="font-bold text-sm text-gray-800">— Sarah K.</p>
                        </div>
                        <div class="p-6 bg-gray-50 rounded-xl">
                            <div class="flex text-yellow-400 mb-3"><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">star</span><span class="material-symbols-outlined">half_star</span></div>
                            <p class="text-sm text-gray-600 italic mb-4">"Requires proper bankroll management because Martingale can be aggressive, but if you size your base contracts correctly, it's a money printer in crab markets."</p>
                            <p class="font-bold text-sm text-gray-800">— David T.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Final CTA -->
            <div class="py-24 text-center bg-black text-white">
                <h2 class="text-3xl md:text-4xl font-bold mb-6">Ready to Automate Your Strategy?</h2>
                <p class="text-gray-400 mb-8 max-w-xl mx-auto">Join the platform, connect your exchange, and let the mathematical grid manage your risk 24/7.</p>
                <button onclick="nav('register')" class="bg-white text-black font-bold px-8 py-3 rounded-lg hover:bg-gray-200 transition shadow-lg">Create Free Account</button>
            </div>
        </section>

        <!-- PUBLIC ANALYTICS PAGE -->
        <section id="view-analytics" class="view-section max-w-4xl mx-auto px-4 py-16">
            <div class="text-center mb-10">
                <span class="material-symbols-outlined text-4xl text-black">monitoring</span>
                <h2 class="text-3xl font-bold mt-2">Platform Analytics</h2>
                <p class="text-gray-500 mt-2">Real-time statistics of user activity across the RDCA Engine ecosystem.</p>
            </div>

            <div class="grid sm:grid-cols-3 gap-6 mb-8">
                <div class="ui-card p-6 border border-gray-100 text-center">
                    <p class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center justify-center gap-1"><span class="material-symbols-outlined text-[16px] text-green-500">wifi</span> Users Online Now</p>
                    <p id="stat-online" class="text-4xl font-mono font-bold text-black">0</p>
                </div>
                <div class="ui-card p-6 border border-gray-100 text-center">
                    <p class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center justify-center gap-1"><span class="material-symbols-outlined text-[16px]">visibility</span> Total Page Views</p>
                    <p id="stat-views" class="text-4xl font-mono font-bold text-black">0</p>
                </div>
                <div class="ui-card p-6 border border-gray-100 text-center">
                    <p class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center justify-center gap-1"><span class="material-symbols-outlined text-[16px]">group</span> Unique Visitors</p>
                    <p id="stat-uniques" class="text-4xl font-mono font-bold text-black">0</p>
                </div>
            </div>

            <div class="ui-card p-6 border border-gray-100">
                <h3 class="text-lg font-bold mb-4 flex items-center gap-2"><span class="material-symbols-outlined text-[20px] text-gray-500">find_in_page</span> Live Page Distribution</h3>
                <div id="stat-pages" class="space-y-2 text-sm text-gray-700 font-mono">
                    <div class="p-4 text-center text-gray-400 font-sans">Loading active pages...</div>
                </div>
            </div>
        </section>

        <!-- LOGIN -->
        <section id="view-login" class="view-section max-w-md w-full mx-auto px-4 py-20">
            <div class="ui-card p-8 border border-gray-100">
                <div class="text-center mb-6">
                    <span class="material-symbols-outlined text-4xl text-black">login</span>
                    <h2 class="text-2xl font-bold mt-2">Welcome Back</h2>
                </div>
                <div class="space-y-5">
                    <div><label class="block text-xs font-semibold text-gray-400 mb-1 uppercase">Email</label><input type="email" id="login-email" class="input-minimal"></div>
                    <div><label class="block text-xs font-semibold text-gray-400 mb-1 uppercase">Password</label><input type="password" id="login-pass" class="input-minimal"></div>
                    <button onclick="doLogin()" class="btn-primary w-full mt-2 py-3">Secure Log In</button>
                    <div id="login-err" class="text-red-500 text-xs text-center font-medium mt-2"></div>
                </div>
            </div>
        </section>

        <!-- REGISTER -->
        <section id="view-register" class="view-section max-w-md w-full mx-auto px-4 py-20">
            <div class="ui-card p-8 border border-gray-100">
                <div class="text-center mb-6">
                    <span class="material-symbols-outlined text-4xl text-black">person_add</span>
                    <h2 class="text-2xl font-bold mt-2">Create Account</h2>
                </div>
                <div class="space-y-5">
                    <div><label class="block text-xs font-semibold text-gray-400 mb-1 uppercase">Name</label><input type="text" id="reg-name" class="input-minimal"></div>
                    <div><label class="block text-xs font-semibold text-gray-400 mb-1 uppercase">Email</label><input type="email" id="reg-email" class="input-minimal"></div>
                    <div><label class="block text-xs font-semibold text-gray-400 mb-1 uppercase">Password</label><input type="password" id="reg-pass" class="input-minimal"></div>
                    <button onclick="doRegister()" class="btn-primary w-full mt-2 py-3">Sign Up & Enter Terminal</button>
                    <div id="reg-err" class="text-red-500 text-xs text-center font-medium mt-2"></div>
                </div>
            </div>
        </section>

        <!-- PRICING / BILLING VIEW -->
        <section id="view-pricing" class="view-section max-w-lg w-full mx-auto px-4 py-20">
            <div class="ui-card p-8 text-center border border-gray-100">
                <span class="material-symbols-outlined text-5xl mb-3 text-green-500">verified_user</span>
                <h2 class="text-2xl font-bold mb-2">Enable Live Trading</h2>
                <p class="text-sm text-gray-500 mb-8">Gain lifetime access to the live execution engine for a one-time setup fee of <strong>$9.99</strong>.</p>
                
                <div id="pricing-unpaid-box">
                    <div class="bg-gray-50 border border-gray-200 rounded-xl p-6 mb-6">
                        <p class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 flex items-center justify-center gap-1"><span class="material-symbols-outlined text-[16px]">currency_bitcoin</span> Send Exactly</p>
                        <p id="btc-amount" class="text-3xl font-mono font-bold text-black mb-5">Loading BTC...</p>
                        
                        <p class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">To Bitcoin (BTC) Address</p>
                        <p class="text-[13px] font-mono bg-white border border-gray-200 py-3 px-3 rounded-md text-gray-800 break-all select-all shadow-inner">bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh</p>
                    </div>

                    <div class="space-y-4 text-left">
                        <div>
                            <label class="block text-xs font-semibold text-gray-400 mb-1 uppercase">Transaction Hash (TXID)</label>
                            <input type="text" id="pay-txid" class="input-minimal font-mono text-sm py-3" placeholder="Paste your 64-character TXID here">
                        </div>
                        <button onclick="submitPayment()" class="btn-primary w-full py-4 text-base flex justify-center items-center gap-2"><span class="material-symbols-outlined text-[20px]">lock_open</span> Confirm Payment & Activate</button>
                        <div id="pay-err" class="text-red-500 text-xs text-center font-medium mt-2"></div>
                    </div>
                </div>

                <div id="pricing-paid-box" class="hidden">
                    <div class="bg-green-50 border border-green-200 rounded-xl p-6 mb-6">
                        <p class="text-green-700 font-bold text-xl mb-1 flex items-center justify-center gap-1"><span class="material-symbols-outlined">check_circle</span> Subscription Active</p>
                        <p class="text-green-600 text-sm">Your account has full lifetime access to live trading capabilities.</p>
                    </div>
                    <button onclick="nav('dashboard')" class="btn-secondary w-full py-3">Return to Trading Terminal</button>
                </div>
            </div>
        </section>

        <!-- DASHBOARD -->
        <section id="view-dashboard" class="view-section max-w-[1400px] w-full mx-auto px-4 sm:px-6 py-8">
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
                <div>
                    <h2 class="text-2xl font-bold flex items-center gap-3">Trading Terminal <span id="statusBadge" class="text-[10px] bg-gray-100 text-gray-600 px-3 py-1 rounded-full uppercase font-bold tracking-wide border border-gray-200">Loading</span></h2>
                    <p class="text-sm text-gray-400 mt-1 flex items-center gap-1"><span class="material-symbols-outlined text-[16px]">schedule</span> Engine Uptime: <span id="uptime" class="font-mono text-gray-700 font-bold">0s</span></p>
                </div>
                <div class="flex gap-3 w-full sm:w-auto">
                    <button onclick="nav('settings')" class="btn-secondary flex-1 sm:flex-none flex justify-center items-center gap-1 shadow-sm"><span class="material-symbols-outlined text-[18px]">key</span> Setup API</button>
                    <button onclick="closeAll()" class="btn-secondary text-red-600 hover:bg-red-50 hover:border-red-200 flex-1 sm:flex-none flex justify-center items-center gap-1 shadow-sm"><span class="material-symbols-outlined text-[18px]">close</span> Close All</button>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <!-- Metrics Grid -->
                <div class="lg:col-span-8 space-y-8">
                    
                    <div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-5 gap-4 sm:gap-6">
                        <div class="ui-card p-5 relative border border-gray-100">
                            <button onclick="resetMetrics()" title="Reset Trade History & PnL" class="absolute top-4 right-4 text-gray-300 hover:text-red-500 transition"><span class="material-symbols-outlined text-[16px]">refresh</span></button>
                            <p class="text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2">Net PnL</p>
                            <p id="netPnl" class="text-lg sm:text-xl font-mono font-bold tracking-tight">$0.0000</p>
                        </div>
                        <div class="ui-card p-5 border border-gray-100">
                            <p class="text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2">Active Margin</p>
                            <p id="marginUsed" class="text-lg sm:text-xl font-mono font-bold tracking-tight text-gray-800">$0.0000</p>
                        </div>
                        <div class="ui-card p-5 border border-gray-100">
                            <p class="text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2">Active Contracts</p>
                            <p id="activeQty" class="text-lg sm:text-xl font-mono font-bold tracking-tight text-gray-800">0</p>
                        </div>
                        <div class="ui-card p-5 border border-gray-100">
                            <p class="text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2">Current ROI</p>
                            <p id="activeRoi" class="text-lg sm:text-xl font-mono font-bold tracking-tight text-gray-800">N/A</p>
                        </div>
                        <div class="ui-card p-5 border border-gray-100">
                            <p class="text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2">Grid Step</p>
                            <p id="dcaStepDisplay" class="text-lg sm:text-xl font-mono font-bold tracking-tight text-yellow-600">0 / 0</p>
                        </div>
                    </div>

                    <!-- Chart -->
                    <div class="ui-card p-6 h-[350px] w-full border border-gray-100">
                        <canvas id="spreadChart"></canvas>
                    </div>

                    <!-- History -->
                    <div class="ui-card p-6 border border-gray-100">
                        <h3 class="text-base font-bold mb-4 flex items-center gap-2"><span class="material-symbols-outlined text-[20px] text-gray-500">receipt_long</span> Recent Executions</h3>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left text-sm whitespace-nowrap">
                                <thead class="text-gray-400 uppercase text-[10px] tracking-wider border-b border-gray-100">
                                    <tr>
                                        <th class="pb-3 px-2">Time</th>
                                        <th class="pb-3 px-2">Side</th>
                                        <th class="pb-3 px-2">Contracts</th>
                                        <th class="pb-3 px-2">Reason</th>
                                        <th class="pb-3 px-2 text-right">ROI</th>
                                        <th class="pb-3 px-2 text-right">PnL</th>
                                    </tr>
                                </thead>
                                <tbody id="tradeHistoryBody" class="font-mono text-xs">
                                    <tr><td colspan="6" class="py-6 text-center text-gray-400 font-sans">No trades recorded.</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Config Sidebar -->
                <div class="lg:col-span-4 h-fit space-y-6">
                    <div class="ui-card p-6 border border-gray-100">
                        <h3 class="text-base font-bold mb-5 flex items-center gap-2 pb-3 border-b border-gray-50"><span class="material-symbols-outlined text-[20px] text-gray-500">tune</span> Strategy Config</h3>
                        
                        <div class="space-y-4 mt-2">
                            <div class="flex justify-between items-center"><label class="text-sm font-medium text-gray-500">Take Profit (%)</label><input type="number" id="tpPctSens" step="0.1" class="input-minimal w-24 py-1.5 text-right font-mono text-green-600 font-bold bg-gray-50"></div>
                            <div class="flex justify-between items-center"><label class="text-sm font-medium text-gray-500">Stop Loss (%)</label><input type="number" id="slPctSens" step="0.1" class="input-minimal w-24 py-1.5 text-right font-mono text-red-600 font-bold bg-gray-50"></div>
                            
                            <hr class="border-gray-100 my-4">

                            <div class="flex justify-between items-center"><label class="text-sm font-medium text-gray-500">Start Contracts</label><input type="number" id="baseContracts" step="1" class="input-minimal w-24 py-1.5 text-right font-mono font-bold bg-gray-50"></div>
                            <div class="flex justify-between items-center" title="If position reaches this amount, close and reverse. 0 disables.">
                                <label class="text-sm font-medium text-gray-500">Max Contracts <span class="text-[10px] block text-gray-400">(0 = Off)</span></label>
                                <input type="number" id="maxContracts" step="1" class="input-minimal w-24 py-1.5 text-right font-mono font-bold text-red-600 bg-gray-50">
                            </div>
                            <div class="flex justify-between items-center" title="Amount of tokens per 1 exchange contract. Example: HTX SHIB = 1000">
                                <label class="text-sm font-medium text-gray-500">Contract Size</label>
                                <input type="number" id="contractSize" step="1" class="input-minimal w-24 py-1.5 text-right font-mono font-bold text-gray-400 bg-gray-50">
                            </div>
                            
                            <hr class="border-gray-100 my-4">
                            
                            <div class="flex justify-between items-center"><label class="text-sm font-medium text-gray-500 flex items-center gap-1"><span class="material-symbols-outlined text-[16px]">grid_on</span> Martingale DCA</label><input type="checkbox" id="dcaEnable" class="w-5 h-5 cursor-pointer accent-black"></div>
                            <div class="flex justify-between items-center" title="The price drop percentage to trigger next DCA"><label class="text-sm font-medium text-gray-500 pl-6">Spread (%)</label><input type="number" id="dcaSpread" step="0.1" class="input-minimal w-24 py-1.5 text-right font-mono bg-gray-50"></div>
                            <div class="flex justify-between items-center" title="Contract volume multiplier applied at each step"><label class="text-sm font-medium text-gray-500 pl-6">Multiplier (x)</label><input type="number" id="dcaMultiplier" step="0.1" class="input-minimal w-24 py-1.5 text-right font-mono bg-gray-50"></div>
                            <div class="flex justify-between items-center"><label class="text-sm font-medium text-gray-500 pl-6">Max Steps</label><input type="number" id="dcaSteps" step="1" class="input-minimal w-24 py-1.5 text-right font-mono bg-gray-50"></div>
                            
                            <button onclick="saveConfig()" class="btn-primary w-full mt-6 py-3 text-sm tracking-wide shadow-sm flex items-center justify-center gap-2"><span class="material-symbols-outlined text-[18px]">save</span> Update Strategy</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- API SETTINGS VIEW -->
        <section id="view-settings" class="view-section max-w-lg mx-auto px-4 py-10">
            <button onclick="nav('dashboard')" class="text-sm font-medium text-gray-400 hover:text-black mb-8 flex items-center gap-1 transition"><span class="material-symbols-outlined text-[18px]">arrow_back</span> Back to Terminal</button>
            <div class="ui-card p-8 border border-gray-100">
                <h2 class="text-2xl font-bold mb-6 flex items-center gap-2"><span class="material-symbols-outlined">api</span> API Integration</h2>
                <div class="space-y-6">
                    <div class="flex items-center gap-3 p-4 bg-gray-50 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-100 transition" onclick="handleLiveToggle()">
                        <input type="checkbox" id="liveTrade" class="w-5 h-5 accent-black pointer-events-none">
                        <label class="text-sm font-bold text-gray-800 cursor-pointer pointer-events-none">Enable Live Trading Execution</label>
                    </div>
                    <div><label class="block text-xs font-semibold text-gray-400 mb-2 tracking-wide uppercase">HTX API Key</label><input type="password" id="apiKey" class="input-minimal font-mono tracking-widest text-lg bg-gray-50"></div>
                    <div><label class="block text-xs font-semibold text-gray-400 mb-2 tracking-wide uppercase">HTX API Secret</label><input type="password" id="apiSecret" class="input-minimal font-mono tracking-widest text-lg bg-gray-50"></div>
                    <button onclick="saveApiKeys()" class="btn-primary w-full py-3 mt-2 tracking-wide shadow-sm flex items-center justify-center gap-2"><span class="material-symbols-outlined text-[18px]">power_settings_new</span> Save & Restart Engine</button>
                    <div id="key-msg" class="text-sm text-center font-medium mt-3"></div>
                </div>
            </div>
        </section>

    </main>

    <footer class="py-10 mt-auto border-t border-gray-200 bg-white">
        <div class="max-w-6xl mx-auto px-4 text-center text-sm text-gray-400 font-medium leading-relaxed">
            &copy; <script>document.write(new Date().getFullYear())</script> RDCA Mathematical Engine. All rights reserved. <br>
            Cryptocurrency trading carries severe financial risk. Use at your own discretion.
        </div>
    </footer>

    <!-- App Logic Scripts -->
    <script>
        let authToken = localStorage.getItem('bot_token');
        let chartPoints = 800;
        let userHasSub = false;

        // ANALYTICS TRACKING SETUP
        let sessionTrackId = localStorage.getItem('rdca_visitor_id');
        if (!sessionTrackId) {
            sessionTrackId = Math.random().toString(36).substring(2, 15);
            localStorage.setItem('rdca_visitor_id', sessionTrackId);
        }
        let currentPageView = 'home';

        async function pingAnalytics(isViewRecord = false) {
            try {
                await fetch('/api/analytics/track', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ sessionId: sessionTrackId, page: currentPageView, isView: isViewRecord })
                });
            } catch(e) {}
        }

        setInterval(() => pingAnalytics(false), 10000); 

        // NAVIGATION LOGIC
        function nav(viewId) {
            document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active-view'));
            document.getElementById('view-' + viewId).classList.add('active-view');
            window.scrollTo(0,0);
            
            currentPageView = viewId;
            pingAnalytics(true); 

            if(viewId === 'dashboard' && authToken) initDashboard();
            if(viewId === 'pricing' && authToken) renderPricingPage();
            if(viewId === 'analytics') fetchAnalyticsData();
        }

        function toggleAuthUI() {
            if (authToken) {
                document.getElementById('nav-public').classList.add('hidden');
                document.getElementById('nav-private').classList.remove('hidden');
                document.getElementById('nav-private').classList.add('flex');
            } else {
                document.getElementById('nav-public').classList.remove('hidden');
                document.getElementById('nav-private').classList.add('hidden');
                document.getElementById('nav-private').classList.remove('flex');
            }
        }

        function logout() { localStorage.removeItem('bot_token'); authToken = null; toggleAuthUI(); nav('home'); }

        async function doAPI(endpoint, method, body) {
            const headers = { 'Content-Type': 'application/json' };
            if (authToken) headers['Authorization'] = authToken;
            const res = await fetch(endpoint, { method, headers, body: body ? JSON.stringify(body) : undefined });
            const data = await res.json();
            if (res.status === 401) { logout(); return { error: "Session expired" }; }
            if (res.status === 403) { return { error: data.error, isForbidden: true }; }
            return data;
        }

        async function doLogin() {
            const email = document.getElementById('login-email').value; const password = document.getElementById('login-pass').value;
            const res = await doAPI('/api/auth/login', 'POST', { email, password });
            if (res.error) document.getElementById('login-err').innerText = res.error;
            else { authToken = res.token; localStorage.setItem('bot_token', authToken); document.getElementById('nav-user-name').innerText = res.user.name; toggleAuthUI(); nav('dashboard'); }
        }

        async function doRegister() {
            const name = document.getElementById('reg-name').value; const email = document.getElementById('reg-email').value; const password = document.getElementById('reg-pass').value;
            const res = await doAPI('/api/auth/register', 'POST', { name, email, password });
            if (res.error) document.getElementById('reg-err').innerText = res.error;
            else { authToken = res.token; localStorage.setItem('bot_token', authToken); document.getElementById('nav-user-name').innerText = res.user.name; toggleAuthUI(); nav('dashboard'); }
        }

        function handleLiveToggle() {
            if (!userHasSub) {
                alert("Live Trading requires an active subscription. Redirecting to billing page.");
                nav('pricing');
                return;
            }
            const cb = document.getElementById('liveTrade');
            cb.checked = !cb.checked;
        }

        async function saveApiKeys() {
            const btn = document.getElementById('key-msg'); btn.innerText = "Connecting to Exchange..."; btn.className = "text-sm text-center font-medium mt-3 text-gray-400";
            const res = await doAPI('/api/user/keys', 'POST', { apiKey: document.getElementById('apiKey').value, apiSecret: document.getElementById('apiSecret').value, liveTradingEnabled: document.getElementById('liveTrade').checked });
            
            if(res.isForbidden) {
                btn.innerText = res.error; btn.className = "text-sm text-center font-medium mt-3 text-red-500"; 
                document.getElementById('liveTrade').checked = false; 
                setTimeout(() => nav('pricing'), 1500);
            }
            else if(res.error) { 
                btn.innerText = res.error; btn.className = "text-sm text-center font-medium mt-3 text-red-500"; 
                document.getElementById('liveTrade').checked = false; 
            }
            else { 
                btn.innerText = "Keys secured. Engine Ready."; btn.className = "text-sm text-center font-medium mt-3 text-green-600"; 
                setTimeout(() => nav('dashboard'), 1500); 
            }
        }

        async function saveConfig() {
            const payload = {
                tpPct: document.getElementById("tpPctSens").value, 
                slPct: document.getElementById("slPctSens").value, 
                baseContracts: document.getElementById("baseContracts").value,
                maxContracts: document.getElementById("maxContracts").value,
                contractSize: document.getElementById("contractSize").value,
                dcaEnabled: document.getElementById("dcaEnable").checked, 
                dcaSpread: document.getElementById("dcaSpread").value,
                dcaMultiplier: document.getElementById("dcaMultiplier").value,
                dcaSteps: document.getElementById("dcaSteps").value
            };
            await doAPI('/api/user/config', 'POST', payload);
            alert("Settings updated & saved securely to database.");
        }

        async function closeAll() { if(confirm("Force close position?")) await doAPI('/api/close-all', 'GET'); }

        async function resetMetrics() {
            if(confirm("Are you sure you want to reset all Trade History and Net PnL? This cannot be undone.")) {
                await doAPI('/api/user/reset-metrics', 'POST');
                lastTradesCount = -1; 
                fetchMetrics();
            }
        }

        async function renderPricingPage() {
            if (userHasSub) {
                document.getElementById('pricing-unpaid-box').classList.add('hidden');
                document.getElementById('pricing-paid-box').classList.remove('hidden');
            } else {
                document.getElementById('pricing-unpaid-box').classList.remove('hidden');
                document.getElementById('pricing-paid-box').classList.add('hidden');
                try {
                    const priceRes = await fetch('https://api.coindesk.com/v1/bpi/currentprice.json');
                    const priceData = await priceRes.json();
                    const btcUsd = priceData.bpi.USD.rate_float;
                    const amountNeeded = (9.99 / btcUsd).toFixed(6);
                    document.getElementById('btc-amount').innerText = amountNeeded + " BTC";
                } catch(e) { document.getElementById('btc-amount').innerText = "0.000150 BTC"; }
            }
        }

        async function submitPayment() {
            const txid = document.getElementById('pay-txid').value;
            const errDiv = document.getElementById('pay-err');
            errDiv.innerText = "Verifying on blockchain..."; errDiv.className = "text-gray-500 text-xs text-center font-medium mt-2";
            
            const res = await doAPI('/api/user/pay', 'POST', { txid });
            if(res.error) {
                errDiv.innerText = res.error; errDiv.className = "text-red-500 text-xs text-center font-medium mt-2";
            } else {
                errDiv.innerText = "Payment Verified! Unlocking system..."; errDiv.className = "text-green-600 text-xs text-center font-medium mt-2";
                userHasSub = true; setTimeout(() => nav('dashboard'), 1500);
            }
        }

        // Analytics Fetcher
        async function fetchAnalyticsData() {
            if(document.getElementById('view-analytics').classList.contains('active-view') === false) return;
            try {
                const res = await fetch('/api/analytics/stats');
                const data = await res.json();
                
                document.getElementById('stat-online').innerText = data.online;
                document.getElementById('stat-views').innerText = data.views;
                document.getElementById('stat-uniques').innerText = data.uniques;

                let pagesHtml = '';
                for(const [pageName, count] of Object.entries(data.pages)) {
                    pagesHtml += '<div class="flex justify-between items-center p-3 border-b border-gray-100 last:border-0 hover:bg-gray-50">' +
                        '<span class="capitalize font-bold text-gray-800">' + pageName + '</span>' +
                        '<span class="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600 font-bold">' + count + ' Active</span>' +
                        '</div>';
                }
                document.getElementById('stat-pages').innerHTML = pagesHtml || '<div class="p-4 text-center text-gray-400 font-sans">No active pages</div>';
            } catch(e){}
        }

        const ctx = document.getElementById("spreadChart").getContext("2d");
        const spreadChart = new Chart(ctx, {
            type: "line", data: { labels: [], datasets: [{ label: "Price", data: [], borderColor: "#000000", borderWidth: 2.0, pointRadius: 0, tension: 0.1 }] },
            options: { responsive: true, maintainAspectRatio: false, animation: false, scales: { y: { grid: { color: "#f3f4f6" }, ticks: { font: { family: "Roboto Mono" } } }, x: { display: false } }, plugins: { legend: { display: false } } }
        });
        
        let lastChartMid = 0;
        function pushChartData(val) {
            if(val === lastChartMid) return; lastChartMid = val;
            spreadChart.data.labels.push(""); spreadChart.data.datasets[0].data.push(val);
            if(spreadChart.data.labels.length > chartPoints) { spreadChart.data.labels.shift(); spreadChart.data.datasets[0].data.shift(); }
        }

        let dashLoop = null; let settingsLoaded = false; let lastTradesCount = -1;
        
        async function initDashboard() {
            document.getElementById('nav-public').classList.add('hidden'); document.getElementById('nav-private').classList.remove('hidden'); document.getElementById('nav-private').classList.add('flex');
            
            const me = await doAPI('/api/user/me', 'GET');
            if(!me.error) {
                document.getElementById('nav-user-name').innerText = me.name;
                userHasSub = me.hasActiveSubscription;
                document.getElementById('liveTrade').checked = me.liveTradingEnabled;
                document.getElementById('apiKey').value = me.apiKey;
            }

            const history = await doAPI('/api/chart-history', 'GET');
            if(!history.error) { spreadChart.data.labels = []; spreadChart.data.datasets[0].data = []; history.forEach(p => pushChartData(p.htxMid)); spreadChart.update(); }

            if(dashLoop) clearInterval(dashLoop);
            dashLoop = setInterval(fetchMetrics, 2000); fetchMetrics();
        }

        async function fetchMetrics() {
            if(document.getElementById('view-dashboard').classList.contains('active-view') === false) return;
            const data = await doAPI('/api/data', 'GET'); if(data.error) return;

            if(!settingsLoaded) {
                document.getElementById("tpPctSens").value = data.config.takeProfitPct; 
                document.getElementById("slPctSens").value = data.config.stopLossPct; 
                document.getElementById("baseContracts").value = data.config.baseContracts;
                document.getElementById("maxContracts").value = data.config.maxContracts || 0;
                document.getElementById("contractSize").value = data.config.contractSize || 1000;
                document.getElementById("dcaEnable").checked = data.config.dcaEnabled; 
                document.getElementById("dcaSpread").value = data.config.dcaSpreadPct || 1.0;
                document.getElementById("dcaMultiplier").value = data.config.dcaMultiplier || 2.0;
                document.getElementById("dcaSteps").value = data.config.dcaMaxSteps;
                settingsLoaded = true;
            }

            document.getElementById("uptime").innerText = data.uptime + "s";
            
            document.getElementById("netPnl").innerText = "$" + data.metrics.totalNetPnl.toFixed(4);
            document.getElementById("netPnl").className = "text-lg sm:text-xl font-mono font-bold tracking-tight " + (data.metrics.totalNetPnl >= 0 ? "text-green-600" : "text-red-600");

            const badge = document.getElementById("statusBadge");
            if(data.activePositions.length > 0) {
                const p = data.activePositions[0];
                badge.innerText = p.isPaper ? "📝 Paper" : "⚡ Live"; badge.className = "text-[10px] bg-black text-white px-3 py-1 rounded-full uppercase tracking-wide font-bold";
                document.getElementById("activeRoi").innerText = p.exchangeROI.toFixed(2) + "%"; document.getElementById("activeRoi").className = "text-lg sm:text-xl font-mono font-bold tracking-tight " + (p.exchangeROI >= 0 ? "text-green-600" : "text-red-600");
                document.getElementById("marginUsed").innerText = "$" + p.marginUsed.toFixed(4); 
                document.getElementById("activeQty").innerText = p.contracts.toLocaleString();
                document.getElementById("dcaStepDisplay").innerText = (p.dcaStep||0) + " / " + data.config.dcaMaxSteps;
            } else {
                badge.innerText = "WAITING"; badge.className = "text-[10px] bg-gray-100 text-gray-400 px-3 py-1 rounded-full uppercase tracking-wide font-bold";
                document.getElementById("activeRoi").innerText = "N/A"; document.getElementById("activeRoi").className = "text-lg sm:text-xl font-mono font-bold tracking-tight text-gray-800";
                document.getElementById("marginUsed").innerText = "$0.0000"; 
                document.getElementById("activeQty").innerText = "0"; 
                document.getElementById("dcaStepDisplay").innerText = "0 / " + data.config.dcaMaxSteps;
            }

            if(data.metrics.totalTradesCount !== lastTradesCount && data.metrics.trades) {
                lastTradesCount = data.metrics.totalTradesCount;
                const tbody = document.getElementById("tradeHistoryBody"); tbody.innerHTML = "";
                const recent = [...data.metrics.trades].reverse().slice(0, 10);
                if(recent.length === 0) tbody.innerHTML = '<tr><td colspan="6" class="py-6 text-center text-gray-400 font-sans">No trades recorded.</td></tr>';
                recent.forEach(t => {
                    const d = new Date(t.timestamp); const tStr = d.getHours().toString().padStart(2,"0")+":"+d.getMinutes().toString().padStart(2,"0");
                    const qtyStr = t.contracts ? t.contracts.toLocaleString() : "-";
                    tbody.innerHTML += '<tr class="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition">' +
                        '<td class="py-3 px-2 text-gray-400">' + tStr + '</td>' +
                        '<td class="py-3 px-2 font-bold ' + (t.side==='long'?'text-green-600':'text-red-600') + '">' + t.side.toUpperCase() + '</td>' +
                        '<td class="py-3 px-2 text-gray-800 font-bold">' + qtyStr + '</td>' +
                        '<td class="py-3 px-2 text-[10px] text-gray-400 font-sans tracking-wide uppercase">' + t.exitReason + '</td>' +
                        '<td class="py-3 px-2 text-right font-bold ' + (t.roiPct>=0?'text-green-600':'text-red-600') + '">' + t.roiPct.toFixed(2) + '%</td>' +
                        '<td class="py-3 px-2 text-right font-bold ' + (t.netPnl>=0?'text-green-600':'text-red-600') + '">$' + t.netPnl.toFixed(4) + '</td></tr>';
                });
            }

            if(data.marketData && data.marketData.htx) { pushChartData(data.marketData.htx.mid); spreadChart.update(); }
        }

        // Initialize App
        pingAnalytics(true);
        setInterval(fetchAnalyticsData, 4000); 

        if(authToken) { toggleAuthUI(); nav('dashboard'); } 
        else { toggleAuthUI(); nav('home'); }
    </script>
</body>
</html>`);
});

// ==================== APP INITIALIZATION ====================
app.listen(CUSTOM_PORT, async () => {
    console.log(`✅ Server running on port ${CUSTOM_PORT}`);
    await loadAllUsers();
    startMasterStreams();
});
